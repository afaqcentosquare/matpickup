<?php 


Route::group(['namespace'=>'Amcoders\Plugin\WebNotification\http\controllers','middleware'=>'web'],function(){

	//here create your routes

});