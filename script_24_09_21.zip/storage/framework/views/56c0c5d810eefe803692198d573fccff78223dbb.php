

<?php $__env->startSection('content'); ?>
<div class="main-content mt-50">
	<div class="container">
		<div class="row">
			<div class="col-lg-10 offset-lg-1">
				<div class="register-card">
					<div class="register-progress text-center">
						<nav>
							<ul>
								<li class="active">
									<div class="register-progress-number">
										<span>1</span>
									</div>
									<div class="register-progress-body">
										<?php echo e(__('Step 1')); ?>

									</div>
								</li>
								<li class="active">
									<div class="register-progress-number">
										<span>2</span>
									</div>
									<div class="register-progress-body">
										<?php echo e(__('Step 2')); ?>

									</div>
								</li>
								<li class="active">
									<div class="register-progress-number">
										<span>3</span>
									</div>
									<div class="register-progress-body">
										<?php echo e(__('Step 3')); ?>

									</div>
								</li>
							</ul>
						</nav>
					</div>
					<div class="register-main-card">
						<div class="row">
							<div class="col-lg-12">
								<div class="main-info text-center">
									<i class="far fa-check-circle"></i>
									<h4><?php echo e(__("Your request is sent successfully and it's pending for approval")); ?></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/store/register_step_4.blade.php ENDPATH**/ ?>