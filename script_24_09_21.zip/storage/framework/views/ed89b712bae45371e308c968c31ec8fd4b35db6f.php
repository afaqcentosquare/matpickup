 <?php
 $i=0;
 ?>
 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <option value="<?php echo e($category->id); ?>" <?php if($select == $category->id): ?> selected <?php endif; ?>> <?php echo e($category->name); ?></option>

 <?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <?php echo $__env->make('lphelper::lphelper.categoryconfig.child', ['child_category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/vendor/lpress/src/views/lphelper/categoryconfig/parent.blade.php ENDPATH**/ ?>