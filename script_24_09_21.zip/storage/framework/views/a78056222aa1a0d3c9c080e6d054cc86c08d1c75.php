 <nav class="navbar navbar-expand-lg main-navbar">
  <form class="form-inline mr-auto">
    <ul class="navbar-nav mr-3">
      <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
      <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="fas fa-search"></i></a></li>
    </ul>
    
  </form>
  <ul class="navbar-nav navbar-right">
    <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
      <?php if(empty(Auth::user()->avatar) || !file_exists(Auth::user()->avatar)): ?>
      <img src="<?php echo e(asset('admin/img/profile/profile.jpg')); ?>" alt="" class="rounded-circle mr-1">
      <?php else: ?>
      <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" alt="" class="rounded-circle mr-1">
      <?php endif; ?>
      
      <div class="d-sm-none d-lg-inline-block"><?php echo e(__('Hi')); ?>, <?php echo e(Auth::user()->name); ?></div></a>
      <div class="dropdown-menu dropdown-menu-right">
        <div class="dropdown-title"><?php echo e(__('My Id #').Auth::id()); ?></div>
        <a href="<?php echo e(route('admin.admin.mysettings')); ?>" class="dropdown-item has-icon">
          <i class="far fa-user"></i> <?php echo e(__('Profile')); ?>

        </a>
        <div class="dropdown-divider"></div>
        <a href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();" class="dropdown-item has-icon text-danger">
        <i class="fas fa-sign-out-alt"></i>  <?php echo e(__('Logout')); ?>

      </a>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
      </form>
    </div>
  </li>
</ul>
</nav>
<?php /**PATH D:\xampp\htdocs\files\script\resources\views/layouts/backend/partials/header.blade.php ENDPATH**/ ?>