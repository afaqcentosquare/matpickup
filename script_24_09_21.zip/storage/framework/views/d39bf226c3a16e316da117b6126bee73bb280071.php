
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$currency=\App\Options::where('key','currency_icon')->select('value')->first();
?>
<div class="row">
	<div class="col-sm-4">
		<div class="card">
			<div class="card-body text-center">
				<p>
					<?php echo e(__('Earnings this month')); ?> (<?php echo e(date('F')); ?>) 
					<h3><?php echo e(strtoupper($currency->value)); ?><?php echo e(number_format($currentMonthAmount,2)); ?></h3>
					
				</p>
			</div>
		</div>
	</div>
	<div class="col-sm-4">
		<div class="card">
			<div class="card-body text-center">
				<p>
					
					<?php echo e(__('Your balance')); ?>

					<h3><?php echo e(strtoupper($currency->value)); ?><?php echo e(number_format($currentMonthAmount-$lastTransection,2)); ?></h3>
					
				</p>
			</div>
		</div>
	</div>
	<div class="col-sm-4">
		<div class="card">
			<div class="card-body text-center">
				<p>
					<?php echo e(__('Total value of your Earnings')); ?>

					<h3><b><?php echo e(strtoupper($currency->value)); ?><?php echo e(number_format($totals,2)); ?></b></h3>
					
				</p>
			</div>
		</div>
	</div>
	<div class="col-sm-12">
		<div class="card card-primary">
			<div class="card-header">
				<h4><?php echo e(__('History')); ?></h4>
				<form class="card-header-form">
					<div class="input-group">
						<input type="text" name="date" class="form-control daterange-cus" value="<?php echo e($date ?? ''); ?>" required="">
						<div class="input-group-btn">
							<button type="submit" class="btn btn-primary btn-icon"><i class="fas fa-search"></i></button>
						</div>
					</div>

				</form>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table">
						<tr>
							<th><?php echo e(__('ORDER ID')); ?></th>
							<th><?php echo e(__('Commision')); ?></th>
							<th><?php echo e(__('Date')); ?></th>
							<th><?php echo e(__('View')); ?></th>
						</tr>

						<?php $__currentLoopData = $allorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><a href="<?php echo e(route('rider.order.details',$row->order_id)); ?>">#<?php echo e($row->order_id); ?></a></td>
							<td><?php echo e(strtoupper($currency->value)); ?><?php echo e($row->commision); ?></td>
							
							<td><?php echo e($row->created_at->format('Y-F-d')); ?></td>
							<td><a href="<?php echo e(route('rider.order.details',$row->order_id)); ?>" class="btn btn-primary btn-sm"><i class="far fa-eye"></i></a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<?php echo e($allorders->links()); ?>

				</div>
			</div>
		</div>
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/daterangepicker.min.js')); ?>"></script>
<script>
	"use strict";
	$('.daterange-cus').daterangepicker();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/rider/statement/earning.blade.php ENDPATH**/ ?>