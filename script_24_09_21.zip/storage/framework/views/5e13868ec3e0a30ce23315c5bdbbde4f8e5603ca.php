<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
    <h1><?php echo e(__('Dashboard')); ?></h1>
  </div>
  <div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
          <i class="fas fa-money-bill"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4><?php echo e(__('Total Earnings')); ?></h4>
          </div>
          <div class="card-body">
            <?php echo e(number_format($totalearns,2)); ?>

          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-danger">
          <i class="fas fa-hand-holding-usd"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4><?php echo e(__('Total Payouts')); ?></h4>
          </div>
          <div class="card-body">
            <?php echo e(number_format($totalPayouts,2)); ?>

          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-warning">
         <i class="fas fa-utensils"></i>
       </div>
       <div class="card-wrap">
        <div class="card-header">
          <h4><?php echo e(__('Total Restaurant')); ?></h4>
        </div>
        <div class="card-body">
          <?php echo e(number_format($resturents)); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-success">
        <i class="fas fa-users"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4><?php echo e(__('Total Customers')); ?></h4>
        </div>
        <div class="card-body">
         <?php echo e(number_format($customers)); ?>

       </div>
     </div>
   </div>
 </div>                  
</div>
<div class="row">
  <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="card card-statistic-2">
      <div class="card-stats">
        <div class="card-stats-title"><?php echo e(__('Order Statistics')); ?> 

        </div>
        <div class="card-stats-items">
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalPending); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('In Pending')); ?></div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalProccessing); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('In Processing')); ?></div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalCompleted); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('Completed')); ?></div>
          </div>
        </div>
      </div>
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-archive"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4><?php echo e(__('Total Orders')); ?></h4>
        </div>
        <div class="card-body">
          <?php echo e(number_format($totalOrders)); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="card card-statistic-2">
      <div class="card-stats">
        <div class="card-stats-title"><?php echo e(__('Todays order Statistics')); ?> 

        </div>
        <div class="card-stats-items">
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e(number_format($totalTodayPending)); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('In Pending')); ?></div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e(number_format($totalTodayProccessing)); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('In Processing')); ?></div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalTodaComplete); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('Completed')); ?></div>
          </div>
        </div>
      </div>
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-archive"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4><?php echo e(__('Total Orders')); ?></h4>
        </div>
        <div class="card-body">
          <?php echo e(number_format($totalTodaOrders)); ?>

        </div>
      </div>
    </div>
  </div>


  <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="card card-statistic-2">
      <div class="card-stats">
        <div class="card-stats-title"><?php echo e(__('Payout Statistics')); ?> 

        </div>
        <div class="card-stats-items">
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalPayoutPending); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('In Pending')); ?></div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalPayoutPending); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('In Pending')); ?></div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($totalPayoutComplete); ?></div>
            <div class="card-stats-item-label"><?php echo e(__('Completed')); ?></div>
          </div>
        </div>
      </div>
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-archive"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4><?php echo e(__('Total Payouts')); ?></h4>
        </div>
        <div class="card-body">
          <?php echo e(number_format($totalPayoutCount)); ?>

        </div>
      </div>
    </div>
  </div>

</div>

<div class="row">
 <div class="col-lg-6 col-md-6 col-12">

  <div class="card">
    <div class="card-header">
      <h4 class="d-inline"><?php echo e(__('New Resturent Request')); ?></h4>
      <div class="card-header-action">
        <a href="<?php echo e(url('/admin/resturents/requests')); ?>" class="btn btn-primary"><?php echo e(__('View All')); ?></a>
      </div>
    </div>
    <div class="card-body">             
      <ul class="list-unstyled list-unstyled-border">

        <?php $__currentLoopData = $requestResturent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="media">
          <img class="mr-3 rounded-circle" width="50" src="<?php echo e(asset($row->avatar)); ?>" alt="">
          <div class="media-body">
            <?php if(empty($row->email_verified_at)): ?>
            <div class="badge badge-pill badge-danger mb-1 float-right"><?php echo e(__('Not Verified')); ?></div>
            <?php else: ?>
            <div class="badge badge-pill badge-success mb-1 float-right"><?php echo e(__('Verified')); ?></div>
            <?php endif; ?>
            <h6 class="media-title"><a href="<?php echo e(url('/admin/user',$row->id)); ?>"><?php echo e($row->name); ?></a></h6>
            <div class="text-small text-muted"><?php echo e($row->email); ?> <div class="bullet"></div> <span class="text-primary"><?php echo e($row->created_at->diffforHumans()); ?></span></div>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
</div>
<div class="col-lg-6 col-md-6 col-12">

  <div class="card">
    <div class="card-header">
      <h4 class="d-inline"><?php echo e(__('New Rider Request')); ?></h4>
      <div class="card-header-action">
        <a href="<?php echo e(url('/admin/rider/requests')); ?>" class="btn btn-primary"><?php echo e(__('View All')); ?></a>
      </div>
    </div>
    <div class="card-body">             
      <ul class="list-unstyled list-unstyled-border">
        <?php $__currentLoopData = $requestRider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="media">
          <img class="mr-3 rounded-circle" width="50" src="<?php echo e(asset($row->avatar)); ?>" alt="">
          <div class="media-body">
            <?php if(empty($row->email_verified_at)): ?>
            <div class="badge badge-pill badge-danger mb-1 float-right"><?php echo e(__('Not Verified')); ?></div>
            <?php else: ?>
            <div class="badge badge-pill badge-success mb-1 float-right"><?php echo e(__('Verified')); ?></div>
            <?php endif; ?>
            <h6 class="media-title"><a href="<?php echo e(url('/admin/user',$row->id)); ?>"><?php echo e($row->name); ?></a></h6>
            <div class="text-small text-muted"><?php echo e($row->email); ?> <div class="bullet"></div> <span class="text-primary"><?php echo e($row->created_at->diffforHumans()); ?></span></div>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
    </div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-lg-5 col-md-12 col-12 col-sm-12">
    <form id="basicform" method="post" class="needs-validation" novalidate="" action="<?php echo e(route('admin.announcement')); ?>">
      <?php echo csrf_field(); ?>
      <?php
      $json=json_decode($announcement->value ?? '');

      ?>
      <div class="card">
        <div class="card-header">
          <h4><?php echo e(__('Announcement')); ?></h4>
        </div>
        <div class="card-body pb-0">
          <div class="form-group">
            <label><?php echo e(__('Title')); ?></label>
            <input type="text" name="title" class="form-control"  required="" value="<?php echo e($json->title ?? ''); ?>">
            <div class="invalid-feedback">
              Please fill in the title
            </div>
          </div>
          <div class="form-group">
            <label><?php echo e(__('Message')); ?></label>
            <textarea class="form-control" required name="message"><?php echo e($json->message ?? ''); ?></textarea>

            <div class="invalid-feedback">
              Please fill in the title
            </div>
          </div>
          <div class="form-group">
            <label><?php echo e(__('Status')); ?></label>
            <select class="form-control" name="status">
              <option value="1" <?php if($announcement->lang ?? '' == 1): ?> selected="" <?php endif; ?>><?php echo e(__('Show')); ?></option> 
              <option value="0" <?php if($announcement->lang ?? '' == 0): ?> selected="" <?php endif; ?>><?php echo e(__('Hide')); ?></option> 
            </select>
          </div>
        </div>
        <div class="card-footer pt-0">
          <button class="btn btn-primary" type="submit">Save</button>
        </div>
      </div>
    </form>
  </div>
  <div class="col-lg-7 col-md-12 col-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h4><?php echo e(__('New Order')); ?></h4>
        <div class="card-header-action">
          <a href="<?php echo e(url('/admin/order')); ?>" class="btn btn-primary">View All</a>
        </div>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-striped mb-0">
            <thead>
              <tr>
                <th><?php echo e(__('Order Type')); ?></th>
                <th><?php echo e(__('Amount')); ?></th>
                <th><?php echo e(__('Author')); ?></th>
                <th><?php echo e(__('Action')); ?></th>
              </tr>
            </thead>
            <tbody>  
              <?php $__currentLoopData = $newOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                       
              <tr>
                <td>
                  <?php if($row->order_type == 1): ?>
                  <span class="badge badge-success"><?php echo e(__('Home Delivery')); ?></span>
                  <?php else: ?>
                  <span class="badge badge-success"><?php echo e(__('Pickup')); ?></span>
                  <?php endif; ?>

                </td>
                <td><?php echo e(number_format($row->total+$row->shipping)); ?></td>
                <td>
                  <a href="<?php echo e(url('/admin/user',$row->vendor_id)); ?>" class="font-weight-600"><img src="<?php echo e(asset($row->vendor->avatar ?? null)); ?>" alt="" width="30" class="rounded-circle mr-1"> <?php echo e($row->vendor->name ?? null); ?></a>
                </td>
                <td>
                  <a href="<?php echo e(url('/admin/order',$row->id)); ?>" class="btn btn-primary btn-action mr-1"><i class="fas fa-eye"></i></a>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khana\script\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>