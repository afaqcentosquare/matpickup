
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row pt-50">
	<div class="col-sm-12">
		<div class="wrapper">
			<h3><?php echo e($info->title); ?></h3>
			<p><?php echo $info->content->content; ?></p>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/welcome/page.blade.php ENDPATH**/ ?>