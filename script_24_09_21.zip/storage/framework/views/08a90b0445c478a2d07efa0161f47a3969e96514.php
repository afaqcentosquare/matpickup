<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row" id="category_body">
	<div class="col-lg-4">      
		<div class="card">
			<div class="card-body">
				<form id="basicform" method="post" action="<?php echo e(route('store.menu.store')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="type" value="<?php echo e($type); ?>">
					<div class="custom-form">
						<div class="form-group">
							<label for="name"><?php echo e(__('Name')); ?></label>
							<input type="text" name="name" class="form-control" id="name" placeholder="Menu Name">
						</div>
						
						<div class="form-group">
							<label for="p_id"><?php echo e(__('Parent Menu')); ?></label>
							<select class="custom-select mr-sm-2" name="p_id" id="p_id inlineFormCustomSelect">
								<option value="">None</option>
								<?php echo ConfigCategory(1) ?>
								
							</select>
						</div>
						
						<div class="form-group mt-20">
							<button class="btn col-12 btn-primary" type="submit"><?php echo e(__('Add New Menu')); ?></button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-lg-8" >      
		<div class="card">
			<div class="card-body">
				<?php
				if (!empty($req)) {
					$categeories=\App\Category::where('type',1)->where('user_id',Auth::id())->where('name','LIKE','%'.$req.'%' )->latest()->paginate(12);	
				}
				else{
					$categeories=\App\Category::where('type',1)->where('user_id',Auth::id())->latest()->paginate(12);
				}
				?>
				<div class="table-responsive">
					<div class="card-action-filter">
					
						<form id="basicform1" method="post" action="<?php echo e(route('store.menu.des')); ?>">
							<?php echo csrf_field(); ?>
							
								<div class="row ml-1 mt-1">
									
									<div class="form-group">
										<select class="form-control" name="method">
											<option>Select Action</option>
											<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
										</select>
									</div>
								
								<div class="single-filter">
									<button type="submit" class="btn btn-danger ml-1 mt-1"><?php echo e(__('Apply')); ?></button>
								</div>
								</div>

						</div>

						<table class="table category">
							<thead>
								<tr>
									<th class="am-select">
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
											<label class="custom-control-label" for="checkAll"></label>
										</div>
									</th>
									<th class="am-title"><?php echo e(__('Title')); ?></th>
									
									<th class="am-title"><?php echo e(__('count')); ?></th>

								</tr>
							</thead>
							<tbody>

								<?php $__currentLoopData = $categeories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th>
										<div class="custom-control custom-checkbox">
											<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>">
											<label class="custom-control-label" for="customCheck<?php echo e($category->id); ?>"></label>
										</div>
									</th>
									<td>
										<?php echo e($category->name); ?>

										<div class="hover">
											<a href="<?php echo e(route('store.menu.edit',$category->id)); ?>"><?php echo e(__('Edit')); ?></a>
										</div>
									</td>
									
									<td><?php echo e(\App\PostCategory::where('category_id',$category->id)->count()); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</tbody>
						</form>	
						<tfoot>
							<tr>
								<th class="am-select">
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
										<label class="custom-control-label" for="checkAll"></label>
									</div>
								</th>
								<th class="am-title"><?php echo e(__('Title')); ?></th>
								
								<th class="am-categories"><?php echo e(__('Count')); ?></th>

							</tr>
						</tfoot>
					</table>
					<div class="f-right"><?php echo e($categeories->links()); ?></div>
				</div>
				
			</div>
		</div>
	</div>
</div>				


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>

<script type="text/javascript">
	"use strict";

	function success(res){
		location.reload();
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/shop/views/menu/index.blade.php ENDPATH**/ ?>