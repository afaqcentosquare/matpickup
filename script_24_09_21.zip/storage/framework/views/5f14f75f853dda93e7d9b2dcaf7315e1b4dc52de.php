<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row" id="category_body">
	<?php if($type==2): ?>
	<div class="col-lg-4">      
		<div class="card">
			<div class="card-body">
				<form id="basicform" method="post" action="<?php echo e(route('admin.shop.category.store')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="type" value="<?php echo e($type); ?>">
					<div class="custom-form">
						<div class="form-group">
							<label for="name"><?php echo e(__('Name')); ?></label>
							<input type="text" name="name" class="form-control" id="name" placeholder="Category Name">
						</div>
						<div class="form-group">
							<label for="slug"><?php echo e(__('Slug')); ?></label>
							<input type="text" name="slug" class="form-control" id="slug" placeholder="Category slug">
						</div>
						<div class="form-group">
							<label for="p_id"><?php echo e(__('Parent Category')); ?></label>
							<select class="custom-select mr-sm-2" name="p_id" id="p_id inlineFormCustomSelect">
								<option value="">None</option>
								<?php echo ConfigCategory($type) ?>
								
							</select>
						</div>
						<?php if($type==2): ?>
						<?php echo e(mediasection()); ?>

						<?php endif; ?>
						<div class="form-group mt-20">
							<button class="btn col-12 btn-primary" type="submit"><?php echo e(__('Add New Category')); ?></button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<?php if($type==2): ?>
	<div class="col-lg-8" >
	<?php else: ?>
	<div class="col-lg-12" >
	<?php endif; ?>
	      
		<div class="card">
			<div class="card-body">
				<?php
				if (!empty($req)) {
					$categeories=\App\Category::where('type',$type)->where('name','LIKE','%'.$req.'%' )->whereHas('user')->with('user')->latest()->paginate(12);	
				}
				else{
					$categeories=\App\Category::where('type',$type)->whereHas('user')->with('user')->latest()->paginate(12);
				}
				?>
				<div class="table-responsive">
					<div class="card-action-filter">
						
						<form id="basicform1" method="post" action="<?php echo e(route('admin.shop.productcategory')); ?>">
							<?php echo csrf_field(); ?>
							
								<div class="row ml-1 mt-1">
									
									<div class="form-group">
										<select class="form-control" name="method">
											<option>Select Action</option>
											<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
										</select>
									</div>
								
								<div class="single-filter">
									<button type="submit" class="btn btn-danger ml-1 mt-1"><?php echo e(__('Apply')); ?></button>
								</div>
							</div>
						</div>
						<table class="table category">
							<thead>
								<tr>
									<th class="am-select">
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
											<label class="custom-control-label" for="checkAll"></label>
										</div>
									</th>
									<th class="am-title"><?php echo e(__('Title')); ?></th>
									
									<th class="am-title"><?php echo e(__('Created By')); ?></th>

									
									
									<th class="am-title"><?php echo e(__('count')); ?></th>

								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $categeories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th>
										<div class="custom-control custom-checkbox">
											<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>">
											<label class="custom-control-label" for="customCheck<?php echo e($category->id); ?>"></label>
										</div>
									</th>
									<td>
										<?php echo e($category->name); ?>

										<div class="hover">
											<a href="<?php echo e(route('admin.shop.category.edit',$category->id)); ?>"><?php echo e(__('Edit')); ?></a>
										</div>
									</td>
									<td><a href="<?php echo e(url('/admin/user',$category->user->id)); ?>"><?php echo e($category->user->name); ?></a></td>
									
									<?php if($category->type==1): ?>
									<td><?php echo e(\App\PostCategory::where('category_id',$category->id)->count()); ?></td>
									<?php else: ?>
									<td><?php echo e(\App\Usercategory::where('category_id',$category->id)->count()); ?></td>
									<?php endif; ?>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</tbody>
						</form>	
						<tfoot>
							<tr>
								<th class="am-select">
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
										<label class="custom-control-label" for="checkAll"></label>
									</div>
								</th>
								<th class="am-title"><?php echo e(__('Title')); ?></th>
								
									<th class="am-title"><?php echo e(__('Created By')); ?></th>

								
								
								<th class="am-categories"><?php echo e(__('Count')); ?></th>

							</tr>
						</tfoot>
					</table>
					<div class="f-right"><?php echo e($categeories->appends($request->all())->links()); ?></div>
				</div>
				
			</div>
		</div>
	</div>
</div>				
<?php if($type==2): ?>
<?php echo e(mediasingle()); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php if($type==2): ?>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<?php endif; ?>
<script type="text/javascript">
	"use strict";
	(function ($) {

		$('.use').on('click',function(){

			$('#preview').attr('src',myradiovalue);
			$('#preview_input').val(myradiovalue);

		});

	})(jQuery);
	function success(res){
		location.reload();
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/product/views/category/index.blade.php ENDPATH**/ ?>