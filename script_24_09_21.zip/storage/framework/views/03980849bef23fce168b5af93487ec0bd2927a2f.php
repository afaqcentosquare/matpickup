<?php if(!empty($menus)): ?>
	<?php
	$mainMenus=json_decode($menus->data);
	?>
	<?php $__currentLoopData = $mainMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<li  class="<?php echo e($li); ?>" >
		<?php if($icon_position == 'left'): ?><i class="<?php echo e($row->icon); ?>"></i> <?php endif; ?>

		<a <?php if(url()->current() == url($row->href)): ?> class="active" <?php endif; ?> href="<?php echo e(url($row->href)); ?>" <?php if(!empty($row->target)): ?> target="<?php echo e($row->target); ?>" <?php endif; ?>><?php echo e($row->text); ?></a>

		<?php if($icon_position=='right'): ?> <i class="<?php echo e($row->icon); ?>"></i><?php endif; ?>
		<?php if(isset($row->children)): ?> 
		<ul  class="<?php echo e($ul); ?>" >
			<?php $__currentLoopData = $row->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childrens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php echo $__env->make('lphelper::lphelper.lpmenu.child', ['childrens' => $childrens], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<?php endif; ?>
		</li>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\files\script\vendor\lpress\src/views/lphelper/lpmenu/parent.blade.php ENDPATH**/ ?>