

<?php $__env->startSection('content'); ?>
 <!-- map area start -->
    <section>
        <div class="map-area">
            <div class="container-fluid p-0">
                <div class="iframe-filter-map">
                   <div id="contact-map"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- map area end -->

    <!-- filter main area start -->
    <div class="filter-main-area">
        <div class="container">
            <div class="row pt-50">
                <div class="col-lg-6">
                    <div class="offer-title">
                        <h3><span id="total_resurent"></span> <?php echo e(__('Restaurants')); ?></h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="resturant-pagination f-right">
                        <div class="d-flex">
                            <div class="left-number">
                                <span id="from"></span> - <span id="to"></span>
                            </div>
                            <div class="center-number">
                                <?php echo e(__('of')); ?>

                            </div>
                            <div class="right-number" >
                                <span id="total"></span>
                            </div>
                            <div class="left-icon">
                                <a href="javascript:void(0)" id="last_page_url"><i class="fas fa-angle-left"></i></a>
                            </div>
                            <div class="right-icon">
                                <a href="javascript:void(0)" id="next_page_url"><i class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>

                    <div class="offer-dropdown f-right">
                        <div class="form-group">
                            <select class="form-control" id="order">
                                <option value="DESC"><?php echo e(__('Latest')); ?></option>
                                <option value="ASC"><?php echo e(__('Old')); ?></option>
                                
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3">
                    <div class="filter-left-section">
                        <div class="single-filter last">
                            <div class="filter-main-title">
                                <h4><?php echo e(__('Filter By')); ?></h4>
                            </div>
                        </div>
                        <div class="single-filter search-area">
                            <div class="filter-search-area">
                                <div class="form-group">
                                    <input type="text" id="restaurants_search" class="form-control" placeholder="<?php echo e(__('button_title')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="single-filter">
                            <div class="single-filter-title">
                                <span><?php echo e(__('Select Location')); ?></span>
                                <div class="sidebar-body">
                                    <div class="category-list">
                                        <nav>
                                            <ul>

                                               <?php
                                                $locations=\App\Terms::where('type',2)->where('status',1)->get();
                                                $crntid=$info->id ?? 0;
                                               ?>

                                               <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="custom-control custom-checkbox">
                                                        <input <?php if($crntid ==$row->id): ?> checked <?php endif; ?> type="radio" class="custom-control-input area" id="customCheck<?php echo e($key); ?>" value="<?php echo e($row->id); ?>" name="area">
                                                        <label class="custom-control-label" for="customCheck<?php echo e($key); ?>"><?php echo e($row->title); ?></label>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single-filter">
                            <div class="single-filter-title">
                                <span><?php echo e(__('category_title')); ?></span>
                                <div class="sidebar-body">
                                    <div class="category-list scroll">
                                        <nav>
                                            <ul>
                                                 
                                               <?php
                                               $categories=\App\Category::where('type',2)->select('id','name')->latest()->get();
                                               if (isset($category)) {
                                                   $cat_row=$category->id;
                                               }
                                               else{
                                                $cat_row='';
                                               }
                                               ?>
                                               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <li>
                                                    <div class="custom-control custom-checkbox">
                                                        <input  type="radio" class="custom-control-input cat" id="customCheckaa<?php echo e($key); ?>" value="<?php echo e($row->id); ?>" <?php if($cat_row == $row->id): ?> checked <?php endif; ?> name="gfg">
                                                        <label class="custom-control-label" for="customCheckaa<?php echo e($key); ?>"><?php echo e($row->name); ?></label>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="filter-right-section">
                        <div class="row" id="resturent_area">
                            <div class="loader-main-area d-none"><div class="loader-area"><div class="loader"></div></div></div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- filter main area end -->
    
    <input type="hidden" id="location_slug" value="<?php echo e($slug ?? ''); ?>">
    <input type="hidden" id="baseurl" value="<?php echo e(url('/')); ?>">
    <input type="hidden" id="location_id" value="<?php echo e($info->id ?? 00); ?>">
   

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('PLACE_KEY')); ?>"></script> 
<script type="text/javascript">
    "use strict";
    var current_lat= <?php echo e($lat); ?>;
    var current_long= <?php echo e($long); ?>;
    var current_zoom= <?php echo e($zoom); ?>;
    var default_image= '<?php echo e(asset('uploads/store.jpg')); ?>';
    var resturent_icon= '<?php echo e(asset('uploads/location.png')); ?>';
</script>
<script src="<?php echo e(theme_asset('khana/public/js/area.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/area/index.blade.php ENDPATH**/ ?>