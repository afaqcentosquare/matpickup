<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(count($category->products) > 0): ?>
<div class="single-category-food mt-50">
	<div class="single-category-main-content">
		<div class="row">
			<div class="col-lg-12">
				<div class="category-title">
					<h3><?php echo e($category->name); ?></h3>
				</div>
			</div>
		</div>
		<div class="row">
			<?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-4 mb-30">
				<div class="single-food-card" <?php if($product->addons->count() > 0): ?>  onclick="product_addon('<?php echo e($product->slug); ?>','<?php echo e($store->slug); ?>')" <?php else: ?> onclick="product_add_to_cart('<?php echo e($product->slug); ?>','<?php echo e($store->slug); ?>')" <?php endif; ?>>
					<?php if(!empty($product->preview->content)): ?>
					<div class="food-img">
						<?php
						$thumbnail=ImageSize($product->preview->content,'medium');
						?>
						<img src="<?php echo e(asset($thumbnail)); ?>" alt="">
					</div>
					<?php endif; ?>
					<div class="food-another">
						<h5><?php echo e($product->title); ?></h5>
						<p><?php echo e($product->excerpt->content ?? ''); ?></p>
						<div class="food-price-action d-flex">
							<?php
							$currency=\App\Options::where('key','currency_name')->select('value')->first();
							?>
							<span class="food-price"><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($product->price->price,2)); ?></span>
							<div class="food-action">
								<a href="javascript:void(0)"><i class="fas fa-plus"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/layouts/section/storeproduct.blade.php ENDPATH**/ ?>