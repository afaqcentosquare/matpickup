
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Payout History'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
  <div class="col-12 mt-2">
    <div class="card">
      <div class="card-body">
        <?php
        $paid=\App\Transactions::where('status',1)->sum('amount');
        $pending=\App\Transactions::where('status',2)->sum('amount');
        $cancel=\App\Transactions::where('status',0)->sum('amount');
        ?>
      <div class="float-left">
        <button class="btn btn-success" type="button"><?php echo e(__('Total Paid Of Amount '.number_format($paid))); ?></button>
         <button class="btn btn-warning" type="button"><?php echo e(__('Total Pending Of Amount '.number_format($pending))); ?></button>
         <button class="btn btn-danger" type="button"><?php echo e(__('Total Cancel Of Amount '.number_format($cancel))); ?></button>
       </div> 
      <div class="float-right">
        <form>
          <div class="input-group mb-2 col-12">

            <input type="number" class="form-control" placeholder="Search..." required="" name="src" autocomplete="off" value="<?php echo e($src ?? ''); ?>" >
            <select class="form-control" name="type">
              <option value="user_id"><?php echo e(__('Search By User Id')); ?></option>
              <option value="id"><?php echo e(__('Search By Transaction Id')); ?></option>
            </select>
            <div class="input-group-append">                                            
              <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </form>
      </div>
      <div class="table-responsive">
        <table class="table table-striped table-hover text-center table-borderless">
          <thead>
            <tr>
              <th><?php echo e(__('Transaction Id')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Method')); ?></th>
              <th><?php echo e(__('Payment Status')); ?></th>
                           
              <th><?php echo e(__('Requested At')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('admin.payout.show',$row->id)); ?>">#<?php echo e($row->id); ?></a></td>
              <td><?php echo e(number_format($row->amount)); ?></td>
              <td><?php echo e($row->payment_mode); ?></td>
              <td><?php if($row->status==0): ?>
                <span class="badge badge-danger"><?php echo e(__('Canceled')); ?></span>
                <?php elseif($row->status==1): ?>
                <span class="badge badge-success"><?php echo e(__('Completed')); ?></span> <?php elseif($row->status==2): ?>
                <span class="badge badge-primary">
                  <?php echo e(__('Pending')); ?>


                <?php endif; ?></td>
              <td><?php echo e($row->created_at->diffforHumans()); ?></td>
              <td><a href="<?php echo e(route('admin.payout.show',$row->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th><?php echo e(__('Transaction Id')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Method')); ?></th>
               <th><?php echo e(__('Payment Status')); ?></th>            
              <th><?php echo e(__('Requested At')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </tfoot>
        </table>
        <?php echo e($requests->links()); ?>

      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Plugins/shop/views/admin/payouts/history.blade.php ENDPATH**/ ?>