
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'My Orders'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$currency=\App\Options::where('key','currency_name')->select('value')->first();
?>
<div class="row">

  <div class="col-12">
    <div class="card mb-0">
      <div class="card-body">
        <ul class="nav nav-pills">
          <li class="nav-item">
            <a class="nav-link <?php if(url()->full() ==  route('rider.orders')): ?> active <?php endif; ?>" href="<?php echo e(route('rider.orders')); ?>"><?php echo e(__('All Orders')); ?><span class="badge <?php if(url()->full() ==  route('rider.orders')): ?> badge-white <?php else: ?> badge-info <?php endif; ?>"><?php echo e($allorders ?? \App\Riderlog::where('user_id',Auth::id())->count()); ?></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php if(url()->full() ==  route('rider.orders','status=1')): ?> active <?php endif; ?>" href="<?php echo e(route('rider.orders','status=1')); ?>"><?php echo e(__('Accepted Orders')); ?><span class="badge badge-primary"><?php echo e($accepted ??  \App\Riderlog::where('user_id',Auth::id())->where('status',1)->count()); ?></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php if(url()->full() ==  route('rider.orders','status=2')): ?> active <?php endif; ?>" href="<?php echo e(route('rider.orders','status=2')); ?>"><?php echo e(__('Pending Orders')); ?><span class="badge badge-warning"><?php echo e($pendings ?? \App\Riderlog::where('user_id',Auth::id())->where('status',2)->count()); ?></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php if(url()->full() ==  route('rider.orders','status=0')): ?> active <?php endif; ?>" href="<?php echo e(route('rider.orders','status=0')); ?>"><?php echo e(__('Declined Orders')); ?><span class="badge badge-danger"><?php echo e($declineds ?? \App\Riderlog::where('user_id',Auth::id())->where('status',0)->count()); ?></span></a>
          </li>
          <li class="nav-item ">
            <a class="nav-link <?php if(url()->full() ==  route('rider.orders','status=complete')): ?> active <?php endif; ?>" href="<?php echo e(route('rider.orders','status=complete')); ?>"><?php echo e(__('Completed Orders')); ?><span class="badge badge-success"><?php echo e($completed ?? \App\Riderlog::where('user_id',Auth::id())->where('status',1)->wherehas('completed')->count()); ?></span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>


  <div class="col-12 mt-2">
    <div class="card">
      <div class="card-body">
        <div class="float-left">
          <form method="get" action="<?php echo e(route('rider.orders')); ?>">
           
            <div class="row">

              <div class="form-group ml-3">
                <label><?php echo e(__('Starting Date')); ?></label>
                <input type="date" name="start" class="form-control" required value="<?php echo e($start ?? ''); ?>">
              </div>
              <div class="form-group ml-2">
               <label><?php echo e(__('Starting Date')); ?></label>
               <input type="date" name="end" class="form-control" required value="<?php echo e($end ?? ''); ?>">
             </div>
           

             <div class="form-group mt-4">
              <button class="btn btn-primary btn-lg  ml-2 mt-1" type="submit"><?php echo e(__('Filter')); ?></button>
            </div>
          </div>
        </form>
      </div>
      <div class="float-right">
        <form action="<?php echo e(route('rider.orders')); ?>">
          <div class="input-group mt-3 col-12">

            <input type="text" class="form-control" placeholder="Search By Order ID" required="" name="src" value="<?php echo e($src ?? ''); ?>">
            <div class="input-group-append">                                            
              <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </form>
      </div>


      <div class="table-responsive">
        <table class="table table-striped table-hover text-center table-borderless">
          <thead>
            <tr>
              <th><?php echo e(__('Order ID')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('Time')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

           
            <tr>
              <td><a href="<?php echo e(route('rider.order.details',$row->order_id)); ?>">#<?php echo e($row->order_id); ?></a></td>
              
              <td><?php echo e(strtoupper($currency->value)); ?> <?php echo e($row->orders->total + $row->orders->shipping); ?></td>
              
              
              <td><?php if($row->status == 1): ?> <span class="badge badge-success"><?php echo e(__('Accepted')); ?></span> <?php elseif($row->status == 2): ?> <span class="badge badge-primary"> <?php echo e(__('Pending')); ?> </span> <?php elseif($row->status == 3): ?> <span class="badge badge-warning"> <?php echo e(__('Accepted')); ?> </span> <?php elseif($row->status == 0): ?>  <span class="badge badge-danger"> <?php echo e(__('Cancelled')); ?> </span> <?php endif; ?></td>
            
              <td><?php echo e($row->created_at->diffforHumans()); ?></td>
              <td><a href="<?php echo e(route('rider.order.details',$row->order_id)); ?>" class="btn btn-primary"><i class="fas fa-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>

          <tfoot>
            <tr>
              <th><?php echo e(__('Order ID')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('Time')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </tfoot>
        </table>
        <?php echo e($orders->links()); ?>

      </div>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/rider/order/index.blade.php ENDPATH**/ ?>