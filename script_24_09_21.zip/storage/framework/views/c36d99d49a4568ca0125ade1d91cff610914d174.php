
<?php $__env->startSection('content'); ?>
	<div class="row">
				<div class="col-lg-4">
					<div class="card">
						<div class="card-header">
							<h4><?php echo e(__('New Orders')); ?></h4>
						</div>
						<div class="card-body" id="neworders">
							
						</div>
					</div>
				</div>
				<div class="col-lg-4">
          <div class="card">
            <div class="card-header">
              <h4><?php echo e(__('Accepted')); ?></h4>
            </div>
            <div class="card-body">
              <?php $__currentLoopData = $accepteorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('theme::rider.section.singleorder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
			<div class="col-lg-4">
          <div class="card">
            <div class="card-header">
              <h4><?php echo e(__('Done')); ?></h4>
            </div>
            <div class="card-body">
              <?php $__currentLoopData = $completeorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('theme::rider.section.singleorder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<input type="hidden" value="" id="ringurl">		
<?php
$currency=\App\Options::where('key','currency_name')->select('value')->first();
?>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	"use strict";
	var baseurl= "<?php echo e(route('store.order.create')); ?>";
	var mainUrl= "<?php echo e(url('/')); ?>";
	var currency= "<?php echo e(strtoupper($currency->value)); ?>";
  var ringurl = '<?php echo e(url('uploads/audio/ring.mp3')); ?>';
</script>
<script src="<?php echo e(theme_asset('khana/public/js/rider/live.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/rider/order/live.blade.php ENDPATH**/ ?>