
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=> $info->name.' Information'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
  <div class="col-sm-4">
    <div class="card">
      <div class="card-header">
        <h5><?php echo e(__('Primary Information')); ?></h5>
      </div>
      <form method="post" action="<?php echo e(route('admin.vendor.update',$info->id)); ?>" id="basicform">
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <div class="form-group">
            <label><?php echo e(__('Name')); ?></label>
            <input type="text" name="name" class="form-control" autocomplete="off" value="<?php echo e($info->name); ?>" required="">
          </div>
          <div class="form-group">
            <label><?php echo e(__('Email')); ?></label>
            <input type="email" name="email" class="form-control" autocomplete="off" value="<?php echo e($info->email); ?>" required>
          </div>
          <div class="form-group">
            <label><?php echo e(__('Password')); ?></label>
            <input type="password" name="password" class="form-control" autocomplete="off" minlength="8">
            
          </div>
          <div class="form-group">
            <label><?php echo e(__('Status')); ?></label>
            <select class="form-control" name="status">
             <option value="pending" <?php if($info->status=='pending'): ?> selected <?php endif; ?>><?php echo e(__('Pending')); ?></option>
             <option value="approved" <?php if($info->status=='approved'): ?> selected <?php endif; ?>><?php echo e(__('Approved')); ?></option>
             <option value="suspended" <?php if($info->status=='suspended'): ?> selected <?php endif; ?>><?php echo e(__('Suspended')); ?></option>
             <option value="cancelled" <?php if($info->status=='cancelled'): ?> selected <?php endif; ?>><?php echo e(__('Cancelled')); ?></option>
           </select>
         </div>
         <div class="form-group">

           <input type="checkbox" name="password_change" value="1" id="check">
           <label for="check"><span class="text-danger"><?php echo e(__('With Change Password')); ?></span></label>
         </div>
         <button class="btn btn-primary col-12" type="submit"><?php echo e(__('Update')); ?></button>
       </div>
       
     </form>
   </div>
 </div>
 <div class="col-sm-8">
  <div class="card">
   <div class="card-header">
    <h5><?php echo e(__('Other Information')); ?></h5>
  </div>
  <div class="card-body">
   <div class="row">
    <?php if(!empty($info->info)): ?>
     <div class="col-sm-5">
      <?php
     
      $json=json_decode($info->info->content);
      ?>
       <p><b><?php echo e(__('Average Delevery Time:')); ?> </b><?php echo e($info->delivery->content ?? ''); ?></p>
       <p><b><?php echo e(__('Average Pickup Time:')); ?> </b><?php echo e($info->pickup->content ?? ''); ?></p>
       <p><b><?php echo e(__('Support Email 1:')); ?> </b><?php echo e($json->email1 ?? ''); ?></p>
       <p><b><?php echo e(__('Support Email 2:')); ?> </b><?php echo e($json->email2 ?? ''); ?></p>
       <p><b><?php echo e(__('Support Phone 1:')); ?> </b><?php echo e($json->phone1 ?? ''); ?></p>
       <p><b><?php echo e(__('Support Phone 2:')); ?> </b><?php echo e($json->phone2 ?? ''); ?></p>
       <p><b><?php echo e(__('City:')); ?> </b><?php echo e($info->resturentlocationwithcity->area->title ?? ''); ?></p>
       <p><b><?php echo e(__('Address line:')); ?> </b><?php echo e($json->address_line ?? ''); ?></p>
       <p><b><?php echo e(__('Location line:')); ?> </b><?php echo e($json->full_address ?? ''); ?></p>
       <p><b><?php echo e(__('Subscription Plan :')); ?> </b><a href="<?php echo e(route('admin.plan.edit', $info->usersaas->id ?? '')); ?>"><?php echo e($info->usersaas->name ?? ''); ?></a></p>
     </div>
     <?php endif; ?>
     <div class="col-sm-7"  id="map-canvas"></div>
   </div>
 </div>
</div>
</div>
<div class="col-sm-8 mt-2">
  <div class="card">
    <div class="card-header">
      <h6><?php echo e(__('Order History')); ?></h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-striped table-hover text-center table-borderless">
          <thead>
            <tr>
              <th><?php echo e(__('Order ID')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Type')); ?></th>
              <th><?php echo e(__('Created at')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('admin.order.details',$row->id)); ?>">#<?php echo e($row->id); ?></a></td>
               <td>
              <?php if($row->status == 1): ?> 
                <span class="badge badge-success"><?php echo e(__('Completed')); ?></span>
                 <?php elseif($row->status == 2): ?> 
                 <span class="badge badge-primary"> <?php echo e(__('Pending')); ?> </span>
                 <?php elseif($row->status == 3): ?> <span class="badge badge-warning"> <?php echo e(__('Accepted')); ?> </span> 
                 <?php elseif($row->status == 0): ?>  <span class="badge badge-danger"> <?php echo e(__('Cancelled')); ?> </span> 
               <?php endif; ?>
             </td>
             
              <td><?php echo e($row->total); ?></td>
              <td>
            <?php if($row->order_type == 1): ?>
               <?php echo e(__('Home Delivery')); ?>

                <?php else: ?> <?php echo e(__('Pickup')); ?> 
              <?php endif; ?>
              </td>
              
              <td><?php echo e($row->created_at->diffforHumans()); ?></td>
              <td><a href="<?php echo e(route('admin.order.details',$row->id)); ?>" class="btn btn-primary"><i class="fas fa-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th><?php echo e(__('Order ID')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Type')); ?></th>
              <th><?php echo e(__('Created at')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </tfoot>
        </table>
        <?php echo e($orders->links()); ?>


      </div>
    </div>
  </div>
</div>
<div class="col-sm-4 mt-2">
  <div class="card">
    <div class="card-header">
      <h6><?php echo e(__('Overview Of Earnings')); ?></h6>
    </div>
    <div class="card-body">
      <ul class="list-group">
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <?php echo e(__('Amount Of Sell')); ?>

          <span class="badge badge-primary badge-pill"><?php echo e($total_amount); ?></span>
          
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <?php echo e(__('Commission')); ?>

          <span class="badge badge-primary badge-pill"><?php echo e($total_commission); ?></span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <?php echo e(__('Earnings')); ?>

          <span class="badge badge-primary badge-pill"><?php echo e($total_amount-$total_commission); ?></span>
        </li>
      </ul>
    </div>
  </div>
</div>

<div class="col-6 mt-2">
  <div class="card">
    <div class="card-header">
      <h6><?php echo e(__('Onesignal History')); ?></h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-striped table-hover text-center table-borderless">
          <thead>
            <tr>
              <th><?php echo e(__('Signal ID')); ?></th>
              <th><?php echo e(__('Register At')); ?></th>
              <th><?php echo e(__('Delete')); ?></th>

            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $info->Onesignal ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($row->player_id); ?></td>
              <td><?php echo e($row->created_at->diffforHumans()); ?></td>
              <td><a href="<?php echo e(route('admin.signal.remove',$row->id)); ?>" class="btn btn-danger btn-danger"><i class="far fa-trash-alt"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th><?php echo e(__('Signal ID')); ?></th>
              <th><?php echo e(__('Register At')); ?></th>
              <th><?php echo e(__('Delete')); ?></th>
            </tr>
          </tfoot>
        </table>

      </div>
    </div>
  </div>
</div>

<div class="col-6 mt-2">
  <div class="card">
    <div class="card-header">
      <h6><?php echo e(__('Transaction History')); ?></h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-striped table-hover text-center table-borderless">
          <thead>
            <tr>
              <th><?php echo e(__('Transection ID')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('admin.payout.show',$row->id)); ?>">#<?php echo e($row->id); ?></a></td>
              <td><?php echo e($row->amount); ?></td>
              <td>
              <?php if($row->status==0): ?>
                <span class="badge badge-danger"><?php echo e(__('Canceled')); ?></span>
                <?php elseif($row->status==1): ?>
                <span class="badge badge-success"><?php echo e(__('Completed')); ?></span> <?php elseif($row->status==2): ?>
                <span class="badge badge-primary">
                  <?php echo e(__('Processing')); ?>


                <?php endif; ?>
              </td>
              <td><a href="<?php echo e(route('admin.payout.show',$row->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th><?php echo e(__('Transection ID')); ?></th>
              <th><?php echo e(__('Amount')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </tfoot>
        </table>
        <?php echo e($transactions->links()); ?>


      </div>
    </div>
  </div>
</div>
</div>

<input type="hidden" value="<?php echo e($info->resturentlocationwithcity->latitude ?? 00.00); ?>" id="latitude">
<input type="hidden" value="<?php echo e($info->resturentlocationwithcity->longitude ?? 00.00); ?>" id="longitude">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('PLACE_KEY')); ?>&libraries=places&callback=initialize"></script>
<script>
  "use strict";
  function initialize() {

    var mapOptions, map, marker, searchBox, city,
      infoWindow = '',
     
      latEl = document.querySelector( '#latitude' ),
      longEl = document.querySelector( '#longitude' ),
      element = document.getElementById( 'map-canvas' );
      city = document.querySelector( '#city' );

    mapOptions = {
      // How far the maps zooms in.
      zoom: 13,
      // Current Lat and Long position of the pin/
      center: new google.maps.LatLng( $('#latitude').val(), $('#longitude').val()),
     
      disableDefaultUI: false, // Disables the controls like zoom control on the map if set to true
      scrollWheel: true, // If set to false disables the scrolling on the map.
      draggable: true, // If set to false , you cannot move the map around.
      // mapTypeId: google.maps.MapTypeId.HYBRID, // If set to HYBRID its between sat and ROADMAP, Can be set to SATELLITE as well.
       maxZoom: 21, // Wont allow you to zoom more than this
      

    };

    /**
     * Creates the map using google function google.maps.Map() by passing the id of canvas and
     * mapOptions object that we just created above as its parameters.
     *
     */
    // Create an object map with the constructor function Map()
    map = new google.maps.Map( element, mapOptions ); // Till this like of code it loads up the map.

    /**
     * Creates the marker on the map
     *
     */
    marker = new google.maps.Marker({
      position: mapOptions.center,
      map: map,
      draggable: false
    });


  }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/shop/views/admin/vendors/show.blade.php ENDPATH**/ ?>