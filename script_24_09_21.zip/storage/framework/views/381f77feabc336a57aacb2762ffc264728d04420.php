

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/bootstrap-datetimepicker.min.css')); ?>">
<style>
	.owl-nav {
		display: none;
	}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
$currency=\App\Options::where('key','currency_name')->select('value')->first();
?>
<!-- success-alert start -->
<div class="alert-message-area">
	<div class="alert-content">
		<h4 class="ale"><?php echo e(__('Your Settings Successfully Updated')); ?></h4>
	</div>
</div>
<!-- success-alert end -->

<!-- error-alert start -->
<div class="error-message-area">
	<div class="error-content">
		<h4 class="error-msg"></h4>
	</div>
</div>
<!-- error-alert end -->

<!-- modal area start -->
<section>
	<div class="modal-area d-none">
		<div class="modal-main-content">

		</div>
	</div>
</section>
<!-- modal area end -->
<input type="hidden" id="gallery_url" value="<?php echo e(route('store.gallery')); ?>">
<section>
	<div class="store-area store_fixed">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-9 p-0">
					<div class="store-left-section">
						<div class="store-banner-img">
							<img src="<?php echo e(asset($store->preview->content)); ?>" alt="">
							<div class="conatiner">
								<div class="badge-area">
									<img src="<?php echo e($store->badge->preview->content ?? null); ?>" alt="">
								</div>
								<div class="row">
									<div class="col-lg-8 p-0">
										<div class="store-info">
											<div class="store-logo d-flex">
												<img src="<?php echo e(asset($store->avatar)); ?>" alt="">
												<div class="store-another-content d-block">
													<div class="d-flex">
														<h3><?php echo e($store->name); ?></h3> <span class="badge badge-red"><?php echo e($store->status == 'offline' ? 'closed' : 'Open'); ?></span>
													</div>
													<?php 
													$json_info = json_decode($store->info->content);
													?>
													<p class="first"><i class="fas fa-map-marker-alt"></i> <?php echo e($json_info->full_address); ?></p>
													<p><i class="fas fa-map-pin"></i> <?php echo e($json_info->address_line); ?></p>

												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-4 p-0">
										<div class="store-main-info f-right">
											<div class="store-avg-time">
												<div class="delivery-ag-time">
													<i class="far fa-clock"></i>
													<span><?php echo e($store->delivery->content); ?> <?php echo e(__('MIN')); ?></span>
												</div>
											</div>
											<div class="store-rating-area d-flex">
												<div class="total-avg-rating">
													<p><i class="fas fa-star"></i> <?php echo e(number_format($store->avg_ratting->content,1)); ?></p>
												</div>
												<div class="total-rating">
													<p><?php echo e($store->ratting->content); ?> <?php echo e(__('Ratings')); ?></p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="store-action <?php echo e($store->status == 'offline' ? 'offline' : ''); ?>">
							<div class="store-inline-action">
								<nav>
									<ul class="nav nav-tabs">
										<li class="active"><a href="#online_order" data-toggle="tab" class="active"><?php echo e(__('Online Order')); ?></a></li>
										<li><a href="#gallery" data-toggle="tab"><?php echo e(__('Gallery')); ?></a></li>
										<li><a class="restutant_info" onclick="restaurantsinfo('<?php echo e($store->slug); ?>')" href="#info" data-toggle="tab"><?php echo e(__('Restaurant Info')); ?></a></li>
										<input type="hidden" id="resturantinfo_url" value="<?php echo e(route('store.resturantinfo')); ?>">
										<?php if($store->usersaas->table_book==1): ?>
										<li><a href="#book" data-toggle="tab"><?php echo e(__('Book A Table')); ?></a></li>
										<?php endif; ?>
										<li><a href="#rating" data-toggle="tab"><?php echo e(__('Rating & Reviews')); ?></a></li>
									</ul>
								</nav>
							</div>
						</div>
						<div class="tab-content">
							<div class="online-food tab-pane fade in active show" id="online_order">
								<div class="loader-main-area">
									<div class="loader-area">
										<div class="loader"></div>
									</div>
								</div>
							</div>
							<input type="hidden" id="add_to_cart_url" value="<?php echo e(route('add_to_cart')); ?>">
							<input type="hidden" id="cart_update" value="<?php echo e(route('cart.update')); ?>">
							<input type="hidden" id="cart_delete" value="<?php echo e(route('cart.delete')); ?>">
							<div class="online-food tab-pane fade" id="gallery">
								<div class="single-category-food mt-50 mb-50">
									<div class="single-category-main-content">
										<div class="owl-carousel gallery">
											<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-lg-12">
												<img class="img-fluid" src="<?php echo e(asset($gallery)); ?>" alt="">
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>
							</div>
							<div class="online-food tab-pane fade" id="info">
								
							</div>
							<div class="online-food tab-pane fade" id="book">
								<div class="single-category-food mt-50 mb-50">
									<div class="single-category-main-content">
										<div class="row mb-20">
											<div class="col-lg-6">
												<h3><?php echo e(__('Book A Table')); ?></h3>
											</div>
										</div>
										<div class="row">
											<div class="col-lg-12">
												<div class="group-section">
													<form action="<?php echo e(route('book.store',$store->slug)); ?>" method="POST" id="book_form">
														<?php echo csrf_field(); ?>
														<div class="book-table-section">
															<h5 class="mb-15"><?php echo e(__('Booking Information')); ?></h5>
															<div class="form-group">
																<label><?php echo e(__('Number of Guests')); ?></label>
																<input type="text" class="form-control" name="number_of_gutes" placeholder="Number of Guests">
															</div>
															<div class="form-group">
																<label><?php echo e(__('Date Of Booking')); ?></label>
																<input type="text" class="form-control" id="date" name="date" placeholder="Date Of Booking" autocomplete="off">
															</div>
															<h5 class="mb-15 mt-30"><?php echo e(__('Contact Information')); ?></h5>
															<div class="form-group">
																<label><?php echo e(__('Name')); ?></label>
																<input type="text" class="form-control" name="name" placeholder="<?php echo e(__('Name')); ?>">
															</div>
															<div class="form-group">
																<label><?php echo e(__('Email')); ?></label>
																<input type="email" class="form-control" name="email" placeholder="<?php echo e(__('Email')); ?>">
															</div>
															<div class="form-group">
																<label><?php echo e(__('Phone Number')); ?></label>
																<input type="text" class="form-control" name="mobile" placeholder="<?php echo e(__('Phone Number')); ?>">
															</div>
															<div class="form-group">
																<label><?php echo e(__('Your Instructions')); ?></label>
																<textarea class="form-control" name="message"></textarea>
															</div>
															<div class="button-area">
																<button id="book_submit" type="submit"><?php echo e(__('Submit')); ?></button>
															</div>
														</div>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="online-food tab-pane fade" id="rating">
								<div class="single-category-food mt-50 mb-50">
									<div class="single-category-main-content">
										<div class="row">
											<div class="col-lg-6">
												<h3><?php echo e(__('Rating & Reviews')); ?></h3>
											</div>
										</div>
										<div class="row">
											<div class="col-lg-12">
												<div class="room-review pt-30">
													<div class="review-rate">
														<div class="row">
															<div class="col-lg-4">
																<div class="room-review-count text-center">
																	<p><?php echo e(number_format($store->avg_ratting->content,1)); ?></p>
																</div>
															</div>
															<div class="col-lg-8">
																<div class="review-bar">
																	<div class="single-progress-bar">
																		<div class="progressbar-label">
																			<h5><?php echo e(__('5 Star')); ?> <span class="f-right"><?php echo e($five_rattings); ?>%</span></h5>
																			<div class="progress">
																				<div class="progress-bar w-<?php echo e($five_rattings); ?>" role="progressbar" aria-valuenow="<?php echo e($five_rattings); ?>" aria-valuemin="0" aria-valuemax="100"></div>
																			</div>
																		</div>
																	</div>
																	<div class="single-progress-bar">
																		<div class="progressbar-label">
																			<h5><?php echo e(__('4 Star')); ?> <span class="f-right"><?php echo e($four_rattings); ?>%</span></h5>
																			<div class="progress">
																				<div class="progress-bar w-<?php echo e($four_rattings); ?>" role="progressbar" aria-valuenow="<?php echo e($four_rattings); ?>" aria-valuemin="0" aria-valuemax="100"></div>
																			</div>
																		</div>
																	</div>
																	<div class="single-progress-bar">
																		<div class="progressbar-label">
																			<h5><?php echo e(__('3 Star')); ?> <span class="f-right"><?php echo e($three_rattings); ?>%</span></h5>
																			<div class="progress">
																				<div class="progress-bar w-<?php echo e($three_rattings); ?>" role="progressbar" aria-valuenow="<?php echo e($three_rattings); ?>" aria-valuemin="0" aria-valuemax="100"></div>
																			</div>
																		</div>
																	</div>
																	<div class="single-progress-bar">
																		<div class="progressbar-label">
																			<h5><?php echo e(__('2 Star')); ?><span class="f-right"><?php echo e($two_rattings); ?>%</span></h5>
																			<div class="progress">
																				<div class="progress-bar w-<?php echo e($two_rattings); ?>" role="progressbar" aria-valuenow="<?php echo e($two_rattings); ?>" aria-valuemin="0" aria-valuemax="100"></div>
																			</div>
																		</div>
																	</div>
																	<div class="single-progress-bar">
																		<div class="progressbar-label">
																			<h5><?php echo e(__('1 Star')); ?> <span class="f-right"><?php echo e($one_rattings); ?>%</span></h5>
																			<div class="progress">
																				<div class="progress-bar w-<?php echo e($one_rattings); ?>" role="progressbar" aria-valuenow="<?php echo e($one_rattings); ?>" aria-valuemin="0" aria-valuemax="100"></div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="review-all pt-30 pb-30">
														<div class="review-title pb-30">
															<h4><?php echo e(__('All Reviews')); ?></h4>
														</div>
														<div class="review-list">
															<?php $__currentLoopData = $store->vendor_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<div class="media">
																<img src="<?php echo e(asset(App\User::find($review->user_id)->avatar)); ?>" class="mr-3" alt="...">
																<div class="media-body">
																	<h5 class="mt-0 mb-10"><?php echo e(App\User::find($review->user_id)->name); ?> <span class="comment-date"> <?php echo e($review->created_at->diffForHumans()); ?></span>
																	</h5>
																	<div class="review-ratting">
																		<?php if($review->comment_meta->star_rate == 5): ?>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<?php endif; ?>
																		<?php if($review->comment_meta->star_rate == 4): ?>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="far fa-star"></i>
																		<?php endif; ?>
																		<?php if($review->comment_meta->star_rate == 3): ?>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="far fa-star"></i>
																		<i class="far fa-star"></i>
																		<?php endif; ?>
																		<?php if($review->comment_meta->star_rate == 2): ?>
																		<i class="fas fa-star"></i>
																		<i class="fas fa-star"></i>
																		<i class="far fa-star"></i>
																		<i class="far fa-star"></i>
																		<i class="far fa-star"></i>
																		<?php endif; ?>
																		<?php if($review->comment_meta->star_rate == 1): ?>
																		<i class="fas fa-star"></i>
																		<i class="far fa-star"></i>
																		<i class="far fa-star"></i>
																		<i class="far fa-star"></i>
																		<i class="far fa-star"></i>
																		<?php endif; ?>
																	</div>
																	<?php echo e($review->comment_meta->comment); ?>

																</div>
															</div>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 p-0">
					<div class="store-right-section fixed">
						<div class="main_cart">
							<div class="delivery-main-content text-center">
								<form action="<?php echo e(route('checkout.index')); ?>" class="cartform">

								<?php if(Cart::instance('cart_'.$store->slug)->count() > 0): ?>
								<div class="delivery-toogle-action">
									<span class="delivery-title"><?php echo e(__('Delivery')); ?></span>
									<div class="custom-control custom-switch">
										<input type="checkbox" name="delivery_type" value="0" class="custom-control-input" id="uinque_id"> <label class="custom-control-label" for="uinque_id"><?php echo e(__('Pick Up')); ?></label>
										</div>
								</div>
								<input type="hidden" id="pickup_price" value="<?php echo e($store->pickup->content); ?>">
								<input type="hidden" id="delivery_price" value="<?php echo e($store->delivery->content); ?>">
								<div class="delivery-avg-time" id="dummy">
									<i class="fas fa-truck"></i> <?php echo e($store->delivery->content); ?> <?php echo e(__('min')); ?>

								</div>
								<div class="delivery-order-form">
									<h5><?php echo e(__('Your order')); ?> <?php echo e($store->name); ?></h5>
								</div>
								<div class="cart-product-list">
									<?php $__currentLoopData = Cart::instance('cart_'.$store->slug)->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="single-cart-product d-flex">
										<div class="cart-product-title d-block">
											<h5><?php echo e($cart->name); ?></h5>
											<p><?php echo e($cart->options->type); ?></p>
										</div>
										<div class="cart-price-action d-block">
											<span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($cart->price,2)); ?></span>
											<div class="cart-product-action d-flex">
												<?php if($cart->qty > 1): ?>
												<a href="javascript:void(0)" class="right" onclick="limit_minus('<?php echo e($cart->rowId); ?>','<?php echo e($store->slug); ?>')"><span class="ti-minus"></span></a>
												<?php else: ?>
												<a href="javascript:void(0)" onclick="delete_cart('<?php echo e($cart->rowId); ?>','<?php echo e($store->slug); ?>')" class="right"><span class="fas fa-trash"></span></a>
												<?php endif; ?>
												<div class="qty">
													<input type="text" id="total_limit<?php echo e($cart->rowId); ?>" value="<?php echo e($cart->qty); ?>">
												</div>
												<a href="javascript:void(0)" class="left" onclick="limit_plus('<?php echo e($cart->rowId); ?>','<?php echo e($store->slug); ?>')"><span class="ti-plus"></span></a>
											</div>
										</div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								<div class="cart-product-another-information">
									<div class="single-information d-flex">
										<span><?php echo e(__('Subtotal')); ?></span>
										<div class="main-amount">
											<span><?php echo e(__(strtoupper($currency->value))); ?> <?php echo e(Cart::subtotal()); ?></span>
										</div>
									</div>
									<div>
										<div class="checkout-btn">
											<a href="javascript:void(0)" onclick="$('.cartform').submit()"><?php echo e(__('Checkout')); ?></a>
										</div>
									</div>
								</div>
								<?php else: ?>
								<h5 class="mt-20 mb-15"><?php echo e(__('No Item in your Cart')); ?></h5>
								<p class="mb-15"><?php echo e(__("You haven't added anything in your cart yet! Start adding the products you like.")); ?></p>
								<div class="cart-product-another-information">
									<div class="single-information d-flex">
										<span><?php echo e(__('Subtotal')); ?></span>
										<div class="main-amount">
											<span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(Cart::subtotal()); ?></span>
										</div>
									</div>
									<div class="checkout-btn disabled">
										<a href="#" class="disabled"><?php echo e(__('Checkout')); ?></a>
									</div>
								</div>
								<?php endif; ?>
							</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- store area end -->

<?php if($store->status == 'offline'): ?>
<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body offline">
        <div class="close-resturants">
        	<div class="row">
        		<div class="col-lg-11">
        			<h3><?php echo e($store->name); ?> <?php echo e(__('is now closed')); ?></h3>
        		</div>
        		<div class="col-lg-1">
        			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true" class="ti-close"></span>
			        </button>
			    </div>
        	</div>
        	
        	<p><?php echo e(__('The restaurant is closed right now. Check out others that are open or take a look at the menu to plan for your next meal.')); ?></p>
        	<a href="<?php echo e(url('/')); ?>"><?php echo e(__('go to homepage')); ?></a>
        	<a class="tranparent" href="#" data-dismiss="modal" aria-label="Close"><?php echo e(__('Close')); ?></a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
<input type="hidden" id="store_url" value="<?php echo e(route('store_data',$store->slug)); ?>">
<input type="hidden" id="addon_url" value="<?php echo e(route('addon_product')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script src="<?php echo e(theme_asset('khana/public/js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script>
	"use strict";
    $(function () {
        $('#date').datetimepicker({
            format: "dd MM yyyy - HH:11 P",
            showMeridian: true,
            autoclose: true,
            todayBtn: true
        });
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/store/index.blade.php ENDPATH**/ ?>