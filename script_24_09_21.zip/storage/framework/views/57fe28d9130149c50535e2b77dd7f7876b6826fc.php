
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
	if (in_array($category->id, $arr)) {
		$checked = "checked";
	}
	else{
		$checked = "";
	}
?>
<div class="custom-control custom-checkbox"><input  <?php echo e($checked); ?> type="checkbox" name="category[]" class="custom-control-input" value="<?php echo e($category->id); ?>" id="category<?php echo e($category->id); ?>">
	<label class="custom-control-label" for="category<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

	</label>
</div>
<?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('lphelper::lphelper.category.category_child_check', ['child_category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/vendor/lpress/src/views/lphelper/category/category_check.blade.php ENDPATH**/ ?>