 <div class="main-sidebar">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="#"><?php echo e(env('APP_NAME')); ?></a>

    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="#"><?php echo e(Str::limit(env('APP_NAME'), $limit = 1)); ?></a>
    </div>
    <ul class="sidebar-menu">

     <?php $__currentLoopData = AdminSidebar(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $adminmenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php if(isset($adminmenus['child'])): ?>
     <?php
     $active  = $adminmenus['active'] ?? '';
     ?>
     <li class="dropdown <?php echo e($active ? 'active' : ''); ?>">
      <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="<?php echo e($adminmenus['icon'] ?? 'fas fa-columns'); ?>"></i> <span><?php echo e($adminmenus['name']); ?></span></a>
      <ul class="dropdown-menu">
        <?php $__currentLoopData = $adminmenus['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch_key => $adminmenuChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li <?php if($adminmenuChild == url()->current()): ?> class="active" <?php endif; ?>><a class="nav-link <?php echo e($adminmenus['class'] ?? ''); ?>" href="<?php echo e(url($adminmenuChild)); ?>"><?php echo e($ch_key); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </li>
    <?php else: ?>
   
    <li class="<?php if(url($adminmenus['url']) == url()->full()): ?> active <?php endif; ?>">
      <a class="nav-link <?php echo e($adminmenus['class'] ?? ''); ?>"  href="<?php echo e(url($adminmenus['url'])); ?>">
        <i class="<?php echo e($adminmenus['icon'] ?? 'fas fa-columns'); ?>"></i> <span><?php echo e($adminmenus['name']); ?></span>
      </a>
    </li>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </aside>
</div>


<?php /**PATH D:\xampp\htdocs\files\script\resources\views/layouts/backend/partials/sidebar.blade.php ENDPATH**/ ?>