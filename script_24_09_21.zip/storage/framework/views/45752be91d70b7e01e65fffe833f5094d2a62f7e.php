
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'All Media Files'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
	<div class="col-12 mt-2">
		<div class="card">
			<div class="card-body">
				<div class="float-right">
					<form>
						<div class="input-group mb-2 col-12">

							<input type="text" class="form-control" placeholder="Search..." required="" name="src" autocomplete="off" value="<?php echo e($src ?? ''); ?>" >
							<select class="form-control" name="type">

								<option value="user_id"><?php echo e(__('Search By User ID')); ?></option>
								<option value="name"><?php echo e(__('Search By Name')); ?></option>
							</select>
							<div class="input-group-append">                                            
								<button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
							</div>
						</div>
					</form>
				</div>
				<form action="<?php echo e(route('admin.medias.destroy')); ?>" id="basicform">
				<div class="float-left">
					<div class="d-flex">
							<div class="single-filter">
								<div class="form-group">
									<select class="form-control" name="status">
										<option><?php echo e(__('Select Action')); ?></option>
										<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
									</select>
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary mt-1 ml-1"><?php echo e(__('Apply')); ?></button>
							</div>
						</div>
				</div>
				<div class="table-responsive">
					<table class="table table-striped table-hover text-center table-borderless">
						<thead>
							<tr>
								<th class="am-select">
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
										<label class="custom-control-label" for="checkAll"></label>
									</div>
								</th>
								<th><?php echo e(__('File')); ?></th>
								
								<th><?php echo e(__('User Id')); ?></th>
								
								<th><?php echo e(__('Url')); ?></th>
								<th><?php echo e(__('Directory')); ?></th>

								<th><?php echo e(__('Uploaded At')); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<th>
									<div class="custom-control custom-checkbox">
										<input type="checkbox" name="id[]" class="custom-control-input" id="customCheck<?php echo e($row->id); ?>" value="<?php echo e($row->id); ?>">
										<label class="custom-control-label" for="customCheck<?php echo e($row->id); ?>"></label>
									</div>
								</th>
								<td><img src="<?php echo e(asset($row->url)); ?>" height="50"></td>

								<td>
									<?php if(Amcoders\Plugin\Plugin::is_active('shop')): ?>
									<a href="<?php echo e(route('admin.vendor.show',$row->user_id)); ?>">#<?php echo e($row->user_id); ?></a>
									<?php else: ?> 
									#<?php echo e($row->user_id); ?>

									<?php endif; ?>
								</td>
								<td><a href="<?php echo e(url($row->url)); ?>"><?php echo e(Str::limit($row->url, 30)); ?></a></td>
								<td><?php echo e($row->path); ?></td>
								<td><?php echo e($row->created_at->diffforHumans()); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<tfoot>
							<tr>
								<th class="am-select">
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
										<label class="custom-control-label" for="checkAll"></label>
									</div>
								</th>
								<th><?php echo e(__('File')); ?></th>
								
								<th><?php echo e(__('User Id')); ?></th>
								
								<th><?php echo e(__('Url')); ?></th>
								<th><?php echo e(__('Directory')); ?></th>

								<th><?php echo e(__('Uploaded At')); ?></th>
								
							</tr>
						</tfoot>
					</table>
					<?php echo e($medias->links()); ?>

				</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script type="text/javascript">
"use strict";	
	//success response will assign this function
 function success(res){
 	location.reload();
 }
 function errosresponse(xhr){

 	$("#errors").html("<li class='text-danger'>"+xhr.responseJSON[0]+"</li>")
 }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/admin/media/index.blade.php ENDPATH**/ ?>