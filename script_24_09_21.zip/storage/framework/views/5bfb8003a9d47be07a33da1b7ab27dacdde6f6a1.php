
<?php $__env->startSection('content'); ?>
<div class="row">
 <div class="col-lg-9">      
  <div class="card">
   <div class="card-body">
    
    <h4><?php echo e(__('My Information')); ?></h4>
    <form method="post" id="basicform" action="<?php echo e(route('rider.my.information.update')); ?>">
     <?php echo csrf_field(); ?>
     <div class="pt-20">

       <?php
       $json=json_decode($info->info->content ?? '');
       $arr['title']= 'Support Phone Number 1';
       $arr['id']= 'phone1';
       $arr['type']= 'number';
       $arr['placeholder']= 'Support Phone Number';
       $arr['name']= 'phone1';
       $arr['is_required'] = true;
       $arr['value'] = $json->phone1 ?? '';

       echo  input($arr);

       $arr['title']= 'Support Phone Number 2';
       $arr['id']= 'phone2';
       $arr['type']= 'number';
       $arr['placeholder']= 'Support Phone Number';
       $arr['name']= 'phone2';
       $arr['value'] = $json->phone2 ?? '';
       
       echo  input($arr);

      ?>

       <div class="form-group">
         <label><?php echo e(__('Select Your City')); ?></label>
         <select class="form-control" name="city" >
           <?php
          $locations=\App\Terms::where('type',2)->where('status',1)->get();
          
         
           $loc_id=$info->location->term_id ?? 0;
           ?>

           <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value="<?php echo e($row->id); ?>" <?php if($loc_id == $row->id): ?> selected <?php endif; ?>><?php echo e($row->title); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select>
       </div>
       <?php
       $arr['title']= 'Full address';
       $arr['id']= 'location_input';
       $arr['type']= 'text';
       $arr['placeholder']= 'Enter Full Address';
       $arr['name']= 'full_address';
       $arr['is_required'] = true;
       $arr['value'] = $json->full_address ?? '';

       echo  input($arr);

       ?>
       <label>Drag Your Address</label>
       <div id="map-canvas" class="map-canvas"></div>

       <input type="hidden" name="latitude" id="latitude" value="<?php echo e($info->location->latitude ?? '00.00'); ?>">
       <input type="hidden" name="longitude" id="longitude" value="<?php echo e($info->location->longitude ?? '00.00'); ?>">
     </div>
   </div>
 </div>

</div>
<div class="col-lg-3">
  <div class="single-area">
   <div class="card">
    <div class="card-body">
     <h5><?php echo e(__('Publish')); ?></h5>
     <hr>
     <div class="btn-publish">
      <button type="submit" class="btn btn-primary col-12"><i class="fa fa-save"></i> <?php echo e(__('Save')); ?></button>
    </div>
  </div>
</div>
</div>


</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>


<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('PLACE_KEY')); ?>&libraries=places&callback=initialize"></script>
<script src="<?php echo e(theme_asset('khana/public/js/information.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/rider/information.blade.php ENDPATH**/ ?>