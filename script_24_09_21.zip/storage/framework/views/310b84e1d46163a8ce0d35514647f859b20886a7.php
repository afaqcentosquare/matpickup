

<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-body">
		<div class="row mb-30">
			<div class="col-lg-8">
				<h4><?php echo e(__('Review List')); ?></h4>
			</div>
			<div class="col-lg-4">
				<div class="single-filter">
					<div class="form-group">

						<input type="text" id="data_search" class="form-control" placeholder="Enter Value">

					</div>
				</div>
			</div>
		</div>
		<div class="table-responsive custom-table">
			<table class="table">
				<thead>
					<tr>
						<th class="am-title"><?php echo e(__('Review Id')); ?></th>
						<th><?php echo e(__('Restaurant Name')); ?></th>
						<th><?php echo e(__('Reviewer Name')); ?></th>
						<th class="am-tags"><?php echo e(__('Rattings')); ?></th>
						<th class="am-tags"><?php echo e(__('Review')); ?></th>
						<th class="am-tags"><?php echo e(__('Action')); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th>
							<?php echo e($review->id); ?>

						</th>
						<th><?php echo e(App\User::find($review->vendor_id)->name); ?></th>
						<td><?php echo e(App\User::find($review->user_id)->name); ?></td>
						<td><?php echo e($review->comment_meta->star_rate); ?> <?php echo e(__('Star')); ?></td>
						<td><?php echo e($review->comment_meta->comment); ?></td>
						<td>
							<a target="__blank" href="<?php echo e(url('store/'.App\User::find($review->vendor_id)->slug)); ?>" class="btn btn-info"><?php echo e(__('View')); ?></a>
							<a href="<?php echo e(route('admin.review.delete',$review->id)); ?>" class="btn btn-danger"><?php echo e(__('Delete')); ?></a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>

				<tfoot>
					<tr>
						<th class="am-title"><?php echo e(__('Title')); ?></th>
						
						<th class="am-tags"><?php echo e(__('Price')); ?></th>
						<th class="am-tags"><?php echo e(__('Sales')); ?></th>

						<th class="am-tags"><?php echo e(__('Status')); ?></th>

						<th class="am-date"><?php echo e(__('Last Modified')); ?></th>
					</tr>
				</tfoot>
			</table>
			<?php echo e($reviews->links()); ?>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Themes/khana/views/admin/review/index.blade.php ENDPATH**/ ?>