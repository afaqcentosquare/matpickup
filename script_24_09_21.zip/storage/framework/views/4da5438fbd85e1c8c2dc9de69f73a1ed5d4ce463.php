
<?php $__env->startSection('content'); ?>
<div class="row">
 <div class="col-lg-9">      
  <div class="card">
   <div class="card-body">
     <div class="alert alert-danger none errorarea">
      <ul id="errors">

      </ul>
    </div>
    <h4><?php echo e(__('Add new product')); ?></h4>
    <form method="post" class="basicform" action="<?php echo e(route('store.product.store')); ?>">
     <?php echo csrf_field(); ?>
     <div class="custom-form pt-20">

       <?php
       $arr['title']= 'Product Name';
       $arr['id']= 'name';
       $arr['type']= 'text';
       $arr['placeholder']= 'Product Title';
       $arr['name']= 'title';
       $arr['is_required'] = true;

       echo  input($arr);
       ?>

       <div class="form-group">
        <label for="price">Price</label>
        <input type="text" placeholder="Product Price" name="price" class="form-control" id="price" required="" value="" autocomplete="off">
      </div>

      

       <?php
       $arr['title']= 'Excerpt';
       $arr['id']= 'excerpt';
       $arr['placeholder']= 'short description';
       $arr['name']= 'excerpt';
       $arr['is_required'] = true;

       echo  textarea($arr);


       ?>

     </div>
   </div>
 </div>

</div>
<div class="col-lg-3">
  <div class="single-area">
   <div class="card">
    <div class="card-body">
     <h5><?php echo e(__('Publish')); ?></h5>
     <hr>
     <div class="btn-publish">
      <button type="submit" class="btn btn-primary col-12 basicbtn"><i class="fa fa-save"></i> <?php echo e(__('Save')); ?></button>
    </div>
  </div>
</div>
</div>
<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><?php echo e(__('Status')); ?></h5>
   <hr>
   <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="status">
    <option value="1"><?php echo e(__('Published')); ?></option>
    <option value="2"><?php echo e(__('Draft')); ?></option>

  </select>
</div>
</div>
</div>

<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><?php echo e(__('Categories')); ?></h5>
   <hr>
   <div class="scroll-bar-wrap">
     <div class="category-list">
       <?php echo e(AdminCategory(1)); ?>

       <div class="cover-bar"></div>
     </div>
   </div>
 </div>
</div>
</div>


<?php echo e(mediasection()); ?>


<?php if(count($addons) > 0): ?>
<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><?php echo e(__('Addon Product')); ?></h5>
   <hr>
   <div class="scroll-bar-wrap">
     <div class="category-list">
      <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="custom-control custom-checkbox"><input type="checkbox" name="addon[]" class="custom-control-input" value="<?php echo e($addon->id); ?>" id="addon<?php echo e($addon->id); ?>">
        <label class="custom-control-label" for="addon<?php echo e($addon->id); ?>"><?php echo e($addon->title); ?>

        </label>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
</div>
</div>
<?php endif; ?>

</form>

<?php echo e(mediasingle()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<script>
   "use strict";
  (function ($) {
    $('.use').on('click',function(){

      $('#preview').attr('src',myradiovalue);
      $('#preview_input').val(myradiovalue);
      
    });
  })(jQuery);
   //response will assign this function
   function success(res){
     location.reload();
   }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/shop/views/products/create.blade.php ENDPATH**/ ?>