<?php 
$json_info = json_decode($store->info->content);
?>
<div class="single-category-food restaurantsinfo_open mt-50 mb-50">
	<div class="single-category-main-content">
		<div class="row">
			<div class="col-lg-6">
				<div class="restaurant-info-left-section">
					<h3 class="mb-20"><?php echo e(__('Restaurant Info')); ?></h3>
					<p class="mb-20"><?php echo e($json_info->description); ?></p>
					<p class="mb-20"><?php echo e($json_info->full_address); ?></p>
					<div class="contact-info">
						<div class="single-content">
							<i class="fas fa-phone"></i> <?php echo e($json_info->phone1); ?>, <?php echo e($json_info->phone2); ?>

						</div>
						<div class="contact-info">
							<div class="single-content">
								<i class="far fa-envelope"></i> <?php echo e($json_info->email1); ?>, <?php echo e($json_info->email2); ?>

							</div>
						</div><br>
						<div class="contact-info">
							<?php $__currentLoopData = $store->shopday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="single-content">
								 <?php if($day->status==1): ?>
								<i class="far fa-clock"></i> <?php echo e(strtoupper($day->day)); ?>

								 								
								 <?php echo e($day->opening); ?> - <?php echo e($day->close); ?> 
								
								<?php endif; ?>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="restaurant-iframe-map">
					<iframe class="map-size b-0" src="https://maps.google.com/maps?q=<?php echo e($store->location->latitude); ?>,<?php echo e($store->location->longitude); ?>&amp;output=embed"  allowfullscreen=""></iframe><br />
				</div>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-lg-12">
				<div class="restaurant-info-right-section">
					<h3 class="mb-15"><?php echo e(__('Cuisine')); ?></h3>
					<div class="restaurant-service-list">
						<nav>
							<ul>
								<?php $__currentLoopData = $store->shopcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a href="#"><i class="far fa-check-circle"></i>
									<?php echo e($category->name); ?></a></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/layouts/section/resturantinfo.blade.php ENDPATH**/ ?>