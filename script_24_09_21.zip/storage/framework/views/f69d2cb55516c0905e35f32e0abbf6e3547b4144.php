

<?php $__env->startSection('content'); ?>
<div class="main-content mt-50">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 offset-lg-3">
				<div class="login-card">
					<div class="login-header">
						<h5><?php echo e(__('Login your account')); ?></h5>
					</div>	
					<div class="login-body">
						<div class="social-login">
							<h6><?php echo e(__('Login with social account')); ?></h6>
							<div class="social-links">
								<?php if(env('FACEBOOK_CLIENT_ID') != null): ?>
								<a class="facebook" href="<?php echo e(url('login/facebook')); ?>"><i class="fab fa-facebook"></i> <?php echo e(__('Facebook')); ?></a>
								<?php endif; ?>

								<?php if(env('GOOGLE_CLIENT_ID') != null): ?>
								<a class="google" href="<?php echo e(url('login/google')); ?>"><i class="fab fa-google"></i> <?php echo e(__('Google')); ?></a>
								<?php endif; ?>
							</div>
						</div>
						<div class="login-form">
							<form action="<?php echo e(route('login')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<div class="form-group">
									<label><?php echo e(__('Email')); ?></label>
									<input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
									<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Password')); ?></label>
									<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
									<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<div class="remember-section d-flex">
									<div class="remember">
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input area" id="remember" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
											<label class="custom-control-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
										</div>
									</div>
									<div class="forgotten">
										<?php if(Route::has('password.request')): ?>
										<a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot password?')); ?></a>
										<?php endif; ?>
									</div>
								</div>
								<div class="login-button">
									<button type="submit"><?php echo e(__('Login Now')); ?></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Themes/khana/views/login/index.blade.php ENDPATH**/ ?>