

<?php $__env->startSection('content'); ?>
<div class="card"  >
	<div class="card-body">
		<div class="row mb-30">
			<div class="col-lg-6">
				<h4><?php echo e(__('Featured Seller')); ?></h4>
				<div class="cart-filter mb-20">
					<a href="?st=1&type=seller&manage=featured_seller"><?php echo e(__('Featured Seller')); ?></a>
				</div>
			</div>
		</div>
		<div class="cart-filter mb-20">
			<h5><?php echo e(__('Membership')); ?></h5>
			<a href="?st=1&type=seller"><?php echo e(__('All')); ?></a>|
			<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="?st=1&type=<?php echo e($type); ?>&plan=<?php echo e($row->id); ?>"><?php echo e($row->name); ?></a> |
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="card-action-filter">
			<form method="post" id="basicform" action="<?php echo e(route('admin.featured.store')); ?>">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-lg-6">
						<div class="d-flex">
							<div class="single-filter">
								<div class="form-group">
									<select class="form-control" name="status">
										<option value="featured_seller"><?php echo e(__('Featured Seller')); ?></option>
									</select>
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary mt-1 ml-1"><?php echo e(__('Apply for featured')); ?></button>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single-filter f-right">
							<div class="form-group">
								<input type="text" id="data_search" class="form-control" placeholder="Enter Value">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="table-responsive custom-table">
				<table class="table">
					<thead>
						<tr>
							<th class="am-select">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
									<label class="custom-control-label checkAll" for="customCheck12"></label>
								</div>
							</th>
							<th class="am-title"><i class="far fa-image"></i></th>
							<th class="am-title"><?php echo e(__('Store Name')); ?></th>
							<th class="am-title"><?php echo e(__('Email')); ?></th>
							<th class="am-title"><?php echo e(__('Membership Status')); ?></td>
							<th class="am-date"><?php echo e(__('Registered At')); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th>
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($post->id); ?>" value="<?php echo e($post->id); ?>">
									<label class="custom-control-label" for="customCheck<?php echo e($post->id); ?>"></label>
								</div>
							</th>
							<td>
								<img src="<?php echo e(asset($post->avatar)); ?>" height="50">
							</td>
							<td>
								<?php echo e($post->name); ?>

								<div class="hover">
									
									<a href="<?php echo e(url('admin/user',$post->id)); ?>" class="last"><?php echo e(__('View')); ?></a>
								</div>
							</td>
							<td>
								<?php echo e($post->email); ?>

							</td>
							<td>
								<?php echo e($post->plan->name); ?>

							</td>					
													
							
							<td><?php echo e(__('Last Modified')); ?>

								<div class="date">
									<?php echo e($post->updated_at->diffForHumans()); ?>

								</div>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</form>
				<tfoot>
					<tr>
						<th class="am-select">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
								<label class="custom-control-label checkAll" for="customCheck12"></label>
							</div>
						</th>
						<th class="am-title"><i class="far fa-image"></i></th>
						<th class="am-title"><?php echo e(__('Store Name')); ?></th>
						<th class="am-title"><?php echo e(__('Email')); ?></th>
						<th class="am-title"><?php echo e(__('Membership Status')); ?></td>
						<th class="am-date"><?php echo e(__('Registered At')); ?></th>
					</tr>
				</tfoot>
			</table>
			<?php echo e($posts->links()); ?>


		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script type="text/javascript">
	"use strict";	
	//response will assign this function
	function success(res){
		//location.reload();
	}
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/locations/views/featured/seller/create.blade.php ENDPATH**/ ?>