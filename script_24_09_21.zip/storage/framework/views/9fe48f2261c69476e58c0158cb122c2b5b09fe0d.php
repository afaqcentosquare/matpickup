

<?php $__env->startSection('content'); ?>
<?php
$currency=\App\Options::where('key','currency_name')->select('value')->first();
?>
<!-- success-alert start -->
<div class="alert-message-area">
	<div class="alert-content">
		<h4 class="ale"><?php echo e(__('Your Settings Successfully Updated')); ?></h4>
	</div>
</div>
<!-- success-alert end -->

<!-- error-alert start -->
<div class="error-message-area">
	<div class="error-content">
		<h4 class="error-msg"></h4>
	</div>
</div>


   
<!-- error-alert end -->
<!-- main area start -->
<section>
	<div class="main-area pt-50">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<div class="settings-sidebar-card">
						<div class="profile-show-area text-center">
							<div class="profile-img">
								<img src="<?php echo e(asset(Auth::User()->avatar)); ?>" alt="">
							</div>
							<div class="profile-content">
								<h5><?php echo e(Auth::User()->name); ?></h5>
								<span><?php echo e(Auth::User()->email); ?></span>
							</div>
						</div>
						<div class="settings-main-menu">
							<nav>
								<ul class="nav nav-tabs">
									<li>
										<a href="#dashbaord" data-toggle="tab" class="active">
											<i class="fas fa-tachometer-alt"></i> <?php echo e(__('Dashboard')); ?>

										</a>
									</li>
									<li>
										<a href="#orders" data-toggle="tab">
											<i class="fas fa-clone"></i> <?php echo e(__('Orders')); ?>

										</a>
									</li>
									<li>
										<a href="#settings" data-toggle="tab">
											<i class="fas fa-cog"></i> <?php echo e(__('Settings')); ?>

										</a>
									</li>
									<li>
										<a href="#ratting_menu" data-toggle="tab">
											<i class="fas fa-star"></i> <?php echo e(__('Rattings & Reviews')); ?>

										</a>
									</li>
									<li>
										<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" data-toggle="tab">
											<i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

										</a>
										<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
								        <?php echo csrf_field(); ?>
								      </form>
									</li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
				<div class="col-lg-8">
					<div class="tab-content">
						<div class="setting-main-area tab-pane fade in active show" id="dashbaord">
							<div class="settings-content-area">
								<div class="row">
									<?php if(\Session::has('error')): ?>
									<div class="col-lg-12">
										<div class="alert alert-danger">
											<ul>
												<li><?php echo \Session::get('error'); ?></li>
											</ul>
										</div>
									</div> 
									<?php endif; ?>
									<div class="col-lg-6">
										<div class="single-dashboard-widget d-flex">
											<div class="left-icon">
												<i class="fas fa-clone"></i>
											</div>
											<div class="right-area f-right">
												<h5><?php echo e(__('Total Orders')); ?></h5>
												<span><?php echo e(App\Order::where('user_id',Auth::User()->id)->count()); ?></span>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="single-dashboard-widget d-flex">
											<div class="left-icon">
												<i class="fab fa-first-order-alt"></i>
											</div>
											<div class="right-area f-right">
												<h5><?php echo e(__('Pending Orders')); ?></h5>
												<span><?php echo e(App\Order::where([
													['user_id',Auth::User()->id],
													['status',2]
													])->count()); ?></span>
												</div>
											</div>
										</div>
									</div>
									<?php
									$orders=\App\Order::where('user_id',Auth::User()->id)->orderBy('id','DESC')->paginate(20)
									?>
									<div class="row mt-30">
										<div class="col-lg-12">
											<div class="table-responsive">
												<table class="table">
													<thead class="thead-dark">
														<tr>
															<th scope="col"><?php echo e(__('Order Id')); ?></th>
															<th scope="col"><?php echo e(__('Payment Method')); ?></th>
															<th scope="col"><?php echo e(__('Status')); ?></th>
															<th scope="col"><?php echo e(__('Amount')); ?></th>
															<th scope="col"><?php echo e(__('Action')); ?></th>
														</tr>
													</thead>
													<tbody>
														<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<th><?php echo e($order->id); ?></th>
															<td><?php echo e($order->payment_method); ?></td>
															<td>
																<?php if($order->status == 2): ?>
																<div class="badge badge-primary"><?php echo e(__('pending')); ?></div>
																<?php elseif($order->status == 3): ?>
																<div class="badge badge-info"><?php echo e(__('pickup')); ?></div>
																<?php elseif($order->status == 1): ?>
																<div class="badge badge-info"><?php echo e(__('complete')); ?></div>
																<?php elseif($order->status == 0): ?>
																<div class="badge badge-danger"><?php echo e(__('cancel')); ?></div>
																<?php endif; ?>
															</td>
															<td><?php echo e(strtoupper($currency->value)); ?> <?php echo e($order->total + $order->shipping); ?></td>
															<td>
																<div class="order-btn d-flex">
																	<?php if($order->status == 1): ?>
																	<?php if(!$order->review()->count() > 0): ?>
																	<a class="view_btn mr-2 btn-send" href="#" data-toggle="modal" data-target="#send_review_<?php echo e($order->id); ?>"><i class="fas fa-paper-plane"></i></i></a>
																	<?php endif; ?>
																	<?php endif; ?>
																	<a class="view_btn" href="<?php echo e(route('author.order.details',encrypt($order->id))); ?>"><i class="fas fa-eye"></i></a>
																</div>
															</td>
														</tr>


														<?php if($order->status == 1): ?>
														<?php if(!$order->review()->count() > 0): ?>
														<div class="modal fade" id="send_review_<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
															<div class="modal-dialog">
																<div class="modal-content">
																	<div class="modal-header">
																		<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Send Review')); ?></h5>
																		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																			<span aria-hidden="true">&times;</span>
																		</button>
																	</div>
																	<form action="<?php echo e(route('author.review')); ?>" method="POST">
																		<?php echo csrf_field(); ?>
																		<div class="modal-body">
																			<div class="form-group">
																				<label for="ratting" class="col-form-label"><?php echo e(__('Select Ratting')); ?>:</label>
																				<select id="ratting" class="form-control" name="ratting">
																					<option value="5"><?php echo e(__('5 Star')); ?></option>
																					<option value="4"><?php echo e(__('4 Star')); ?></option>
																					<option value="3"><?php echo e(__('3 Star')); ?></option>
																					<option value="2"><?php echo e(__('2 Star')); ?></option>
																					<option value="1"><?php echo e(__('1 Star')); ?></option>
																				</select>
																			</div>
																			<input type="hidden" name="vendor_id" value="<?php echo e($order->vendor_id); ?>">
																			<input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
																			<div class="form-group">
																				<label for="review" class="col-form-label"><?php echo e(__('Write Review')); ?>:</label>
																				<textarea class="form-control" id="review" name="review"></textarea>
																			</div>
																		</div>
																		<div class="modal-footer">
																			<button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
																			<button type="submit" class="btn btn-primary"><?php echo e(__('Send Review')); ?></button>
																		</div>
																	</form>
																</div>
															</div>
														</div>
														<?php endif; ?>
														<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</tbody>
												</table>
											</div>

											<?php echo e($orders->links()); ?>

										</div>
									</div>
								</div>
							</div>
							<div class="setting-main-area verification_area tab-pane fade" id="orders">
								<div class="settings-content-area">
									<h4>Orders</h4>
									<div class="row">
										<div class="col-lg-12">
											<div class="table-responsive">
												<table class="table">
													<thead class="thead-dark">
														<tr>
															<th scope="col"><?php echo e(__('Order Id')); ?></th>
															<th scope="col"><?php echo e(__('Payment Method')); ?></th>
															<th scope="col"><?php echo e(__('Status')); ?></th>
															<th scope="col"><?php echo e(__('Amount')); ?></th>
															<th scope="col"><?php echo e(__('Action')); ?></th>
														</tr>
													</thead>
													<tbody>
														<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<th><?php echo e($order->id); ?></th>
															<td><?php echo e($order->payment_method); ?></td>
															<td>
																<?php if($order->status == 2): ?>
																<div class="badge badge-primary"><?php echo e(__('pending')); ?></div>
																<?php elseif($order->status == 3): ?>
																<div class="badge badge-info"><?php echo e(__(
																'pickup')); ?></div>
																<?php elseif($order->status == 1): ?>
																<div class="badge badge-info"><?php echo e(__('complete')); ?></div>
																<?php elseif($order->status == 0): ?>
																<div class="badge badge-danger"><?php echo e(__('cancel')); ?></div>
																<?php endif; ?>
															</td>
															<td><?php echo e(strtoupper($currency->value)); ?><?php echo e($order->total + $order->shipping); ?></td>
															<td>
																<div class="order-btn d-flex">
																	<?php if($order->status == 1): ?>
																	<?php if(!$order->review()->count() > 0): ?>
																	<a class="view_btn mr-2 btn-send" href="#" data-toggle="modal" data-target="#send_review<?php echo e($order->id); ?>"><i class="fas fa-paper-plane"></i></i></a>
																	<?php endif; ?>
																	<?php endif; ?>
																	<a class="view_btn" href="<?php echo e(route('author.order.details',encrypt($order->id))); ?>"><i class="fas fa-eye"></i></a>
																</div>
															</td>
														</tr>
														<?php if($order->status == 1): ?>
														<?php if(!$order->review()->count() > 0): ?>
														<div class="modal fade" id="send_review<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
															<div class="modal-dialog">
																<div class="modal-content">
																	<div class="modal-header">
																		<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Send Review')); ?></h5>
																		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																			<span aria-hidden="true">&times;</span>
																		</button>
																	</div>
																	<form action="<?php echo e(route('author.review')); ?>" method="POST">
																		<?php echo csrf_field(); ?>
																		<div class="modal-body">
																			<div class="form-group">
																				<label for="ratting" class="col-form-label"><?php echo e(__('Select Ratting')); ?>:</label>
																				<select id="ratting" class="form-control" name="ratting">
																					<option value="5"><?php echo e(__('5 Star')); ?></option>
																					<option value="4"><?php echo e(__('4 Star')); ?></option>
																					<option value="3"><?php echo e(__('3 Star')); ?></option>
																					<option value="2"><?php echo e(__('2 Star')); ?></option>
																					<option value="1"><?php echo e(__('1 Star')); ?></option>
																				</select>
																			</div>
																			<input type="hidden" name="vendor_id" value="<?php echo e($order->vendor_id); ?>">
																			<input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
																			<div class="form-group">
																				<label for="review" class="col-form-label"><?php echo e(__('Write Review')); ?>:</label>
																				<textarea class="form-control" id="review" name="review"></textarea>
																			</div>
																		</div>
																		<div class="modal-footer">
																			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
																			<button type="submit" class="btn btn-primary"><?php echo e(__('Send Review')); ?></button>
																		</div>
																	</form>
																</div>
															</div>
														</div>
														<?php endif; ?>
														<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</tbody>
												</table>
											</div>
											<?php echo e($orders->links()); ?>

										</div>
									</div>
								</div>
							</div>
							<div class="setting-main-area verification_area tab-pane fade" id="settings">
								<div class="settings-content-area">
									<h4><?php echo e(__('Settings')); ?></h4>
									<form action="<?php echo e(route('author.settings.update')); ?>" method="POST" id="user_settings_form">
										<?php echo csrf_field(); ?>
										<div class="row">
											<div class="col-lg-6">
												<div class="form-group">
													<label for="name"><?php echo e(__('Name')); ?></label>
													<input type="text" class="form-control" name="name" placeholder="<?php echo e(__('Name')); ?>" id="name" value="<?php echo e(Auth::User()->name); ?>">
												</div>
											</div>
											<div class="col-lg-6">
												<div class="form-group">
													<label for="email"><?php echo e(__('Email')); ?></label>
													<input type="text" class="form-control" name="email" placeholder="<?php echo e(__('Email')); ?>" id="email" value="<?php echo e(Auth::User()->email); ?>">
												</div>
											</div>
											<div class="col-lg-12">
												<h5><?php echo e(__('Password Change')); ?></h5>
											</div>
											<div class="col-lg-12">
												<div class="form-group">
													<label for="current_password"><?php echo e(__('Current Password')); ?></label>
													<input type="password" class="form-control" placeholder="<?php echo e(__('Current Password')); ?>" name="current_password" id="current_password">
												</div>
											</div>
											<div class="col-lg-6">
												<div class="form-group">
													<label for="new_password"><?php echo e(__('New Password')); ?></label>
													<input type="password" class="form-control" placeholder="<?php echo e(__('New Password')); ?>" name="password" id="new_password">
												</div>
											</div>
											<div class="col-lg-6">
												<div class="form-group">
													<label for="confirm_password"><?php echo e(__('Confirm Password')); ?></label>
													<input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation" id="confirm_password">
												</div>
											</div>
											<div class="col-lg-12">
												<div class="btn-submit f-right">
													<button type="submit"><?php echo e(__('Update')); ?></button>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
							<div class="setting-main-area verification_area tab-pane fade" id="ratting_menu">
								<div class="settings-content-area">
									<h4><?php echo e(__('Rattings & Reviews')); ?></h4>
									<div class="row">
										<div class="col-lg-12">
											<div class="table-responsive">
												<table class="table">
													<thead class="thead-dark">
														<tr>
															<th scope="col">#</th>
															<th scope="col"><?php echo e(__('Resturant Name')); ?></th>
															<th scope="col"><?php echo e(__('Ratting')); ?></th>
															<th scope="col"><?php echo e(__('Review')); ?></th>
															<th scope="col"><?php echo e(__('Action')); ?></th>
														</tr>
													</thead>
													<tbody>
														<?php $__currentLoopData = Auth::User()->user_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<th><?php echo e($key + 1); ?></th>
															<td><a target="__blank" href="<?php echo e(url('store',App\User::find($review->vendor_id)->slug)); ?>"><?php echo e(App\User::find($review->vendor_id)->name); ?></a></td>
															<td><?php echo e($review->comment_meta->star_rate); ?> <?php echo e(__('Star')); ?></td>
															<td><?php echo e(Str::limit($review->comment_meta->comment,20)); ?></td>
															<td><a class="view_btn" href="#"><i class="fas fa-eye"></i></a></td>
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- main area end -->
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Themes/khana/views/author/dashboard.blade.php ENDPATH**/ ?>