
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'All Products'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
	<div class="col-12 mt-2">
		<div class="card">
			<div class="card-body">
				
				<div class="float-right">
					<form>
						<div class="input-group mb-2 col-12">

							<input type="text" class="form-control" placeholder="Search..."  name="src" autocomplete="off" value="<?php echo e($src ?? ''); ?>">
							<select class="form-control" name="type">
								<option value="title"><?php echo e(__('Search By Title')); ?></option>
								
								<option value="id"><?php echo e(__('Search By Product Id')); ?></option>
							</select>
							<div class="input-group-append">                                            
								<button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
							</div>
						</div>
					</form>
				</div>
				<div class="float-left">
					<form id="basicform" method="post" action="<?php echo e(route('admin.product.destroy')); ?>">
						<?php echo csrf_field(); ?>
						<div class="d-flex">
							<div class="single-filter">
								<div class="form-group">
									<select class="form-control" name="status">
										<option><?php echo e(__('Select Action')); ?></option>

										<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
									</select>
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary mt-1 ml-1"><?php echo e(__('Apply')); ?></button>
							</div>
						</div>

					</div>
					<table class="table">
						<thead>
							<tr>
								<th class="am-select">
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
										<label class="custom-control-label" for="checkAll"></label>
									</div>
								</th>
								<th class="am-title"><i class="far fa-image"></i></th>
								<th class="am-title"><?php echo e(__('Title')); ?></th>

								<th class="am-tags"><?php echo e(__('Price')); ?></th>

								<th class="am-tags"><?php echo e(__('Total Sales')); ?></th>
								<th class="am-tags"><?php echo e(__('Status')); ?></th>

								<th class="am-date"><?php echo e(__('Last Modified')); ?></th>
								<th class="am-date"><?php echo e(__('View')); ?></th>

							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<th>
									<div class="custom-control custom-checkbox">
										<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($post->id); ?>" value="<?php echo e($post->id); ?>">
										<label class="custom-control-label" for="customCheck<?php echo e($post->id); ?>"></label>
									</div>
								</th>
								<td><img src="<?php echo e(asset($post->preview->content)); ?>" height="50" alt=""></td>
								<td>
									<?php echo e($post->title); ?>

								</td>

								<td><?php echo e($post->price->price); ?></td>
								<td><?php echo e($post->order_count); ?></td>
								<td><?php if($post->status==1): ?>  Published <?php elseif($post->status==2): ?>  <?php echo e(__('Draft')); ?> <?php else: ?> <?php echo e(__('Trash')); ?> <?php endif; ?></td>
								<td><?php echo e(__('Last Modified')); ?>

									<div class="date">
										<?php echo e($post->updated_at->diffForHumans()); ?>

									</div>
								</td>
								<td><a href="<?php echo e(url('/store/'.$post->user->slug)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
						<tr>
							<th class="am-select">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
									<label class="custom-control-label" for="checkAll"></label>
								</div>
							</th>
							<th class="am-title"><i class="far fa-image"></i></th>
							<th class="am-title"><?php echo e(__('Title')); ?></th>
							<th class="am-tags"><?php echo e(__('Price')); ?></th>
							<th class="am-tags"><?php echo e(__('Total Sales')); ?></th>
							<th class="am-tags"><?php echo e(__('Status')); ?></th>

							<th class="am-date"><?php echo e(__('Last Modified')); ?></th>
							<th class="am-date"><?php echo e(__('View')); ?></th>
						</tr>
					</tfoot>
				</table>
				<?php echo e($posts->links()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script>
	"use strict";	
	//success response will assign this function
	function success(res){
		location.reload();
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/product/views/admin/products.blade.php ENDPATH**/ ?>