
<?php $__env->startSection('content'); ?>
<div class="row">
 <div class="col-lg-9">      
  <div class="card">
   <div class="card-body">
    
    <h4><?php echo e(__('Edit product')); ?></h4>
    <form method="post" class="basicform" action="<?php echo e(route('store.product.update',$info->id)); ?>">
     <?php echo csrf_field(); ?>
     <?php echo method_field('PUT'); ?>
     <div class="custom-form pt-20">

       <?php
       $arr['title']= 'Product Name';
       $arr['id']= 'name';
       $arr['type']= 'text';
       $arr['placeholder']= 'Product Title';
       $arr['name']= 'title';
       $arr['value']= $info->title;
       $arr['is_required'] = true;

       echo  input($arr);
       ?>
       <div class="form-group">
        <label for="price">Price</label>
        <input type="number" placeholder="Product Price" step="any" name="price" class="form-control" id="price" required="" value="<?php echo e($info->price->price); ?>" autocomplete="off" >
      </div>
      
       <?php
       $arr['title']= 'Excerpt';
       $arr['id']= 'excerpt';
       $arr['placeholder']= 'short description';
       $arr['name']= 'excerpt';
       $arr['is_required'] = true;
       $arr['value']= $info->excerpt->content;

       echo  textarea($arr);


       ?>

     </div>
   </div>
 </div>

</div>
<div class="col-lg-3">
  <div class="single-area">
   <div class="card">
    <div class="card-body">
     <h5><?php echo e(__('Publish')); ?></h5>
     <hr>
     <div class="btn-publish">
      <button type="submit" class="btn btn-primary col-12 basicbtn"><i class="fa fa-save"></i> <?php echo e(__('Save')); ?></button>
    </div>
  </div>
</div>
</div>
<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><?php echo e(__('Status')); ?></h5>
   <hr>
   <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="status">
    <option value="1" <?php if($info->status == 1): ?> selected="" <?php endif; ?>><?php echo e(__('Published')); ?></option>
    <option value="2" <?php if($info->status == 2): ?> selected="" <?php endif; ?>><?php echo e(__('Draft')); ?></option>

  </select>
</div>
</div>
</div>

<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><?php echo e(__('Categories')); ?></h5>
   <hr>
   <div class="scroll-bar-wrap">
     <div class="category-list">

      <?php
      $catArr=[];

      foreach ($info->postcategory as $row) {
        array_push($catArr, $row->category_id);
      }
      
      ?>  
       

      <?php echo AdminCategoryUpdate(1, $catArr,true); ?>

      <div class="cover-bar"></div>
    </div>
  </div>
</div>
</div>
</div>


<?php 
if(!empty($info->preview)){
  
    $media['preview'] = $info->preview->content;
    $media['value'] = $info->preview->content;
    echo  mediasection($media);
    
  
  
}
else{
 echo mediasection();
}

?>

<?php if(count($addons) > 0): ?>
<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><?php echo e(__('Addon Product')); ?></h5>
   <hr>
   <div class="scroll-bar-wrap">
     <div class="category-list">
       <?php
      $addonArr=[];

      foreach ($info->addonid as $row) {
        array_push($addonArr, $row->addon_id);
      }
      
      ?>

      <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

       <div class="custom-control custom-checkbox"><input <?php if(in_array($addon->id, $addonArr)): ?> checked <?php endif; ?> type="checkbox" name="addon[]" class="custom-control-input" value="<?php echo e($addon->id); ?>" id="addon<?php echo e($addon->id); ?>">
        <label class="custom-control-label" for="addon<?php echo e($addon->id); ?>"><?php echo e($addon->title); ?>

        </label>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
</div>
</div>
<?php endif; ?>


</div>
</div>
</form>

<?php echo e(mediasingle()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<script>
   "use strict";
  (function ($) {
    $('.use').on('click',function(){

      $('#preview').attr('src',myradiovalue);
      $('#preview_input').val(myradiovalue);
      
    });
  })(jQuery);
   //response will assign this function
   function success(res){
    // location.reload();
   }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Plugins/shop/views/products/edit.blade.php ENDPATH**/ ?>