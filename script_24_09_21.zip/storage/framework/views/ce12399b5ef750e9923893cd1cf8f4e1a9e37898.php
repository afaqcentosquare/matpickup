
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Riders'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
  <div class="col-12 mt-2">
    <div class="card">
      <div class="card-body">
      
      <div class="float-right">
        <form>
          <div class="input-group mb-2 col-12">

            <input type="text" class="form-control" placeholder="Search..." required="" name="src" autocomplete="off" value="<?php echo e($src ?? ''); ?>">
            <select class="form-control" name="type">
              <option value="name"><?php echo e(__('Search By Name')); ?></option>
              <option value="email"><?php echo e(__('Search By Email')); ?></option>
              <option value="id"><?php echo e(__('Search By Id')); ?></option>
            </select>
            <div class="input-group-append">                                            
              <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </form>
      </div>
       <form method="post" action="<?php echo e(route('admin.vendor.destroys')); ?>">
          <?php echo csrf_field(); ?>
         <div class="float-left mr-3">
           
            <div class="input-group col-12 ">

              
              <select class="form-control" name="status">
                <option value="" ><?php echo e(__('Select Action')); ?></option>
                <option value="delete" ><?php echo e(__('Delete Users Permanently')); ?></option>
               
              </select>
              <div class="input-group-append">                                            
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
            </div>
         
        </div>
      <div class="table-responsive">
        <table class="table table-striped table-hover text-center table-borderless">
          <thead>
            <tr>
               <th><input type="checkbox" class="checkAll"></th>
              <th><?php echo e(__('Vendor ID')); ?></th>
              <th><?php echo e(__('Avatar')); ?></th>
              <th><?php echo e(__('Name')); ?></th>
              <th><?php echo e(__('Email')); ?></th>
              
              <?php if($type=='pending'): ?>
              <th><?php echo e(__('Email verified')); ?></th>
              <?php endif; ?>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('Created at')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><input type="checkbox" name="ids[]" value="<?php echo e($row->id); ?>"></td>
              <td><a href="<?php echo e(route('admin.vendor.show',$row->id)); ?>"><?php echo e($row->id); ?></a></td>
              <td><img src="<?php echo e(asset($row->avatar)); ?>" height="30"></td>
              <td><a href="<?php echo e(route('admin.vendor.show',$row->id)); ?>" ><?php echo e($row->name); ?></a></td>
              <td><?php echo e($row->email); ?></td>
              <?php if($type=='pending'): ?>
              <td><?php if(!empty($row->email_verified_at)): ?> <span class="badge badge-success"><?php echo e(__('Verified')); ?></span> <?php else: ?> <span class="badge badge-danger"><?php echo e(__('Not verified')); ?></span>  <?php endif; ?></td>
              <?php endif; ?>
              <td><?php echo e($row->status); ?></td>
              <td><?php echo e($row->created_at->format('Y-F-d')); ?></td>
              <td><a href="<?php echo e(route('admin.vendor.show',$row->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
               <th><input type="checkbox" class="checkAll"></th>
              <th><?php echo e(__('Vendor ID')); ?></th>
              <th><?php echo e(__('Avatar')); ?></th>
              <th><?php echo e(__('Name')); ?></th>
              <th><?php echo e(__('Email')); ?></th>
              <?php if($type=='pending'): ?>
              <th><?php echo e(__('Email verified')); ?></th>
              <?php endif; ?>
              <th><?php echo e(__('Status')); ?></th>

              <th><?php echo e(__('Created at')); ?></th>
              <th><?php echo e(__('View')); ?></th>
            </tr>
          </tfoot>
        </table>
        <?php echo e($users->links()); ?>

      </div>
       </form>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Plugins/shop/views/admin/rider/request.blade.php ENDPATH**/ ?>